#include "wind_runner.h"
#include "model_inputs.h"
#include "divergence.h"
#include "solver/solver.h"
#include "turbulence.h"
#include "winds/TURBGeneralData.h"
#include "winds/WINDSGeneralData.h"
#include <stdexcept>

namespace dtcc_qes {
struct WindRunner::Impl {
  GridConfig grid;
  ModelInputs inputs;
  // Reverse destruction frees solvers, then turbulence (which points at the
  // wind data), then the wind data and its buildings.
  std::unique_ptr<WINDSGeneralData> data;
  std::unique_ptr<TURBGeneralData> turbulence;
  std::unique_ptr<solver::PoissonOperator> poisson;
  std::unique_ptr<solver::SolverState<float>> solver;
  std::unique_ptr<solver::SolverState<double>> precision_solver;
  double tolerance = 0;
  enum class Phase { Prepared, Initialized, Solving, Finalized };
  Phase phase = Phase::Prepared;

  Impl(const GridConfig &g, const ModelSettings &m, const BuildingArrays &b,
       const TurbulenceSettings &t)
    : grid(g), inputs(g, m, b, t),
      data(std::make_unique<WINDSGeneralData>(make_domain(inputs), inputs.buildings,
        inputs.parameterizations, inputs.inflow.site_z0))
  {
    poisson = std::make_unique<solver::PoissonOperator>(*data,solver::CoefficientOwnership::Take);
    if (inputs.turbulence_enabled) {
      check_turbulence_margin(inputs, *data, grid);
      turbulence = std::make_unique<TURBGeneralData>(inputs.turbulence, data.get());
    }
  }
};

WindRunner::WindRunner() = default;
WindRunner::~WindRunner()
{
  const std::lock_guard<std::mutex> lock(native_mutex());
  impl_.reset();
}

void WindRunner::prepare(const GridConfig &grid, const ModelSettings &model,
                         const BuildingArrays &buildings, Messages &messages)
{
  prepare(grid, model, buildings, TurbulenceSettings{}, messages);
}

void WindRunner::prepare(const GridConfig &grid, const ModelSettings &model,
                         const BuildingArrays &buildings, const TurbulenceSettings &turbulence,
                         Messages &messages)
{
  const std::lock_guard<std::mutex> lock(native_mutex());
  const BufferedLogSink sink(messages);
#ifdef _OPENMP
#pragma omp parallel
  {
#pragma omp single
    solver_profile::actual_threads = omp_get_num_threads();
  }
#endif
  solver_profile::mark("prepare");
  auto prepared = std::make_unique<Impl>(grid, model, buildings, turbulence);
  solver_profile::array("wind.z0_domain_u", prepared->data->z0_domain_u);
  solver_profile::array("wind.z0_domain_v", prepared->data->z0_domain_v);
  solver_profile::array("wind.ibuilding_flag", prepared->data->ibuilding_flag);
  solver_profile::array("wind.building_id", prepared->data->building_id);
  solver_profile::array("wind.e", prepared->data->e);
  solver_profile::array("wind.f", prepared->data->f);
  solver_profile::array("wind.g", prepared->data->g);
  solver_profile::array("wind.h", prepared->data->h);
  solver_profile::array("wind.m", prepared->data->m);
  solver_profile::array("wind.n", prepared->data->n);
  solver_profile::array("wind.icellflag", prepared->data->icellflag);
  solver_profile::array("wind.icellflag_initial", prepared->data->icellflag_initial);
  solver_profile::array("wind.building_volume_frac", prepared->data->building_volume_frac);
  solver_profile::array("wind.ni", prepared->data->ni);
  solver_profile::array("wind.nj", prepared->data->nj);
  solver_profile::array("wind.nk", prepared->data->nk);
  solver_profile::array("wind.wall_distance", prepared->data->wall_distance);
  solver_profile::array("wind.center_id", prepared->data->center_id);
  solver_profile::array("wind.terrain", prepared->data->terrain);
  solver_profile::array("wind.terrain_face_id", prepared->data->terrain_face_id);
  solver_profile::array("wind.base_height", prepared->data->base_height);
  solver_profile::array("wind.effective_height", prepared->data->effective_height);
  solver_profile::array("wind.u0", prepared->data->u0);
  solver_profile::array("wind.v0", prepared->data->v0);
  solver_profile::array("wind.w0", prepared->data->w0);
  solver_profile::array("wind.u", prepared->data->u);
  solver_profile::array("wind.v", prepared->data->v);
  solver_profile::array("wind.w", prepared->data->w);
  solver_profile::array("wind.mixingLengths", prepared->data->mixingLengths);
  solver_profile::bytes["operator.owned"] = prepared->poisson->storage_bytes();
  solver_profile::resident("prepared");
  solver_profile::mark("idle");
  impl_.swap(prepared);
}

WindData WindRunner::solve(const WindCondition &condition, const SolverOptions &options, Messages &messages)
{
  const std::lock_guard<std::mutex> lock(native_mutex());
  const BufferedLogSink sink(messages);
  if (!impl_) throw std::runtime_error("Prepare the runner before solving");
  auto &state = *impl_;
  const double tolerance = solver_tolerance(options);
  struct SolveScope {
    Impl &state;
    bool success = false;
    ~SolveScope() {
      state.phase = Impl::Phase::Prepared;
      if (!success) { state.solver.reset(); state.precision_solver.reset(); }
    }
  } scope{state};
  solver_profile::mark("initialization");
  state.inputs.set_condition(condition);
  auto &data = *state.data;
  data.resetICellFlag();
  data.applyWindProfile(state.inputs.inflow);
  data.applyParametrizations();
  state.phase = Impl::Phase::Initialized;
  WindData result;
  solver_profile::mark("workspace_allocation");
  solver::SolveDiagnostics diagnostics;
  try {
    const auto run = [&](auto &workspace) {
      solver_profile::bytes["solver.workspace"] = workspace.workspace_bytes();
      solver_profile::mark("begin_validation_zero_rhs");
      workspace.begin(solver::ConditionInputs(data),options.max_iterations);
      state.phase = Impl::Phase::Solving;
      solver_profile::mark("sweeps");
      workspace.advance(options.max_iterations);
  solver_profile::mark("finalization");
      solver::MassDiagnostics mass;
      workspace.finalize(solver::FaceDestination(data),
                         solver::CenteredDestination{result.velocity,result.cell_flags},&mass);
      solver_profile::mark("solver_other");
      state.phase = Impl::Phase::Finalized;
      result.divergence = {mass.interior_max,mass.interior_rms,mass.top_band_max,mass.cells,mass.top_band_cells};
      return workspace.diagnostics();
    };
    if (options.precision == "float64") {
      state.solver.reset();
      if (!state.precision_solver || state.tolerance != tolerance)
        state.precision_solver = std::make_unique<solver::SolverState<double>>(*state.poisson,tolerance);
      diagnostics = run(*state.precision_solver);
    } else {
      state.precision_solver.reset();
      if (!state.solver || state.tolerance != tolerance)
        state.solver = std::make_unique<solver::SolverState<float>>(*state.poisson,tolerance);
      diagnostics = run(*state.solver);
    }
    state.tolerance = tolerance;
  } catch (...) {
    state.solver.reset(); state.precision_solver.reset();
    state.phase = Impl::Phase::Prepared;
    throw;
  }

  solver_profile::mark("turbulence");
  if (state.turbulence) state.turbulence->run();
  solver_profile::mark("output_extraction");

  if (state.turbulence) result.turbulence = turbulence_fields(*state.turbulence, state.grid);
  result.nx = state.grid.nx;
  result.ny = state.grid.ny;
  result.nz = state.grid.nz;
  result.x = data.domain.x;
  result.y = data.domain.y;
  result.z.assign(data.domain.z.begin() + 1, data.domain.z.end());
  result.z_faces.assign(data.domain.z_face.begin() + 1, data.domain.z_face.end());
  result.building_count = state.inputs.buildings.size();
  result.iterations = diagnostics.iterations;
  result.max_lagrange_multiplier_change = diagnostics.max_lagrange_multiplier_change;
  result.tolerance = diagnostics.tolerance;
  result.converged = diagnostics.converged;
  result.precision = options.precision;
  scope.success = true;
  solver_profile::resident("native_output");
  solver_profile::mark("idle");
  return result;
}
}
