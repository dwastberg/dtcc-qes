// QES-derived mass-consistency solver; GPL-3.0-or-later. See cpu_float32.cpp
// for the original University of Utah / Minnesota Duluth contributor notices.
#pragma once

#include "qes/Domain.h"
#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

class WINDSGeneralData;

namespace dtcc_qes::solver {

enum class SweepOrder { Lexicographic, RedBlack };
enum class StopRule { LegacyTolerance, FixedSweeps };
enum class Phase { Empty, Active, Finalized, Failed };
enum class Termination { None, LegacyTolerance, IterationLimit, FixedBudget };

constexpr SweepOrder default_order() {
#ifdef _OPENMP
  return SweepOrder::RedBlack;
#else
  return SweepOrder::Lexicographic;
#endif
}

// S1 borrows immutable coefficient storage from the prepared geometry. The
// geometry must outlive the operator and must not resize or mutate these arrays.
class PoissonOperator {
public:
  explicit PoissonOperator(const WINDSGeneralData &);
  PoissonOperator(const PoissonOperator &) = delete;
  PoissonOperator &operator=(const PoissonOperator &) = delete;
  const qes::Domain domain;
  const std::vector<float> &e, &f, &g, &h, &m, &n;
};

// The current post-parameterization flags belong to the condition, not the
// geometry operator. All borrowed inputs remain unchanged until finalization.
struct ConditionInputs {
  const qes::Domain &domain;
  const std::vector<float> &u0, &v0, &w0;
  const std::vector<int> &icellflag;
  explicit ConditionInputs(const WINDSGeneralData &);
};

struct FaceDestination {
  std::vector<float> &u, &v, &w;
  explicit FaceDestination(WINDSGeneralData &);
};

// Physical zero-based cell layers, [first, last). Empty intervals are allowed.
struct LayerRange { int first, last; };
struct CenteredDestination {
  std::vector<float> &velocity;
  std::vector<std::int32_t> &cell_flags;
};
struct Observation {
  LayerRange layers;
  int nx = 0, ny = 0;
  std::vector<float> velocity;
  std::vector<std::int32_t> cell_flags;
};

// Physical zero-based cells. Defaults retain the existing excluded lateral and
// highest-layer regions, with the last solved layer reported separately.
struct MassRegion {
  int i_first = 1, i_last = -1, j_first = 1, j_last = -1;
  int k_first = 0, k_last = -1;
};
struct MassDiagnostics {
  double interior_max = 0, interior_rms = 0, top_band_max = 0;
  std::size_t cells = 0, top_band_cells = 0;
};
struct SolveDiagnostics {
  int iterations = 0;
  double max_lagrange_multiplier_change = 0, tolerance = 0;
  bool converged = false;
};
struct WorkReport {
  int completed_sweeps;
  SolveDiagnostics diagnostics;
  Termination termination;
};
template<class Real> struct StudyState {
  std::vector<Real> multipliers, rhs;
};

template<class Real> class SolverState {
public:
  explicit SolverState(const PoissonOperator &, double tolerance = 1e-5,
                       SweepOrder = default_order(), float relaxation = 1.78f);
  SolverState(const SolverState &) = delete;
  SolverState &operator=(const SolverState &) = delete;

  void begin(ConditionInputs, int total_sweeps, StopRule = StopRule::LegacyTolerance);
  WorkReport advance(int work_sweeps);
  Observation observe(LayerRange) const;
  MassDiagnostics diagnose(MassRegion = {}) const;
  void finalize(FaceDestination, std::optional<CenteredDestination> = std::nullopt,
                MassDiagnostics *final_mass = nullptr);
  SolveDiagnostics diagnostics() const;
  Phase phase() const { return phase_; }
  SweepOrder order() const { return order_; }
  Termination termination() const;
  std::size_t workspace_bytes() const;
  StudyState<Real> copy_state_for_study() const;

private:
  // Preserve the legacy kernel names and arithmetic types inside the kernels.
  struct KernelFields {
    const std::vector<float> &e, &f, &g, &h, &m, &n, &u0, &v0, &w0;
    const std::vector<int> &icellflag;
  };
  const PoissonOperator &operator_;
  const qes::Domain &domain;
  const double tolerance_;
  const SweepOrder order_;
  const Real omega;
  const int alpha1 = 1, alpha2 = 1;
  std::vector<Real> R, lambda;
  std::optional<KernelFields> fields_;
  Phase phase_ = Phase::Empty;
  StopRule stop_rule_ = StopRule::LegacyTolerance;
  int iterations_ = 0, total_sweeps_ = 0;
  Real last_change_ = 0;
  void require_iterate() const;
  void build_rhs();
  Real sweep_lexicographic();
  Real sweep_red_black();
  float corrected_face(int component, int i, int j, int k) const;
  float face_value(int component, int i, int j, int k) const;
  bool solid(int i, int j, int k) const;
};

template<> void SolverState<float>::build_rhs();
template<> float SolverState<float>::sweep_lexicographic();
template<> float SolverState<float>::sweep_red_black();
template<> float SolverState<float>::corrected_face(int, int, int, int) const;
template<> void SolverState<double>::build_rhs();
template<> double SolverState<double>::sweep_lexicographic();
template<> double SolverState<double>::sweep_red_black();
template<> float SolverState<double>::corrected_face(int, int, int, int) const;
extern template class SolverState<float>;
extern template class SolverState<double>;

// Embedding/test convenience: orchestration of the same phases, never another
// kernel. Production WindRunner calls the phases itself.
template<class Real> SolveDiagnostics solve_wind(SolverState<Real> &state,
    WINDSGeneralData &wind, int sweeps, StopRule rule = StopRule::LegacyTolerance) {
  state.begin(ConditionInputs(wind), sweeps, rule);
  state.advance(sweeps);
  state.finalize(FaceDestination(wind));
  return state.diagnostics();
}
}
