/****************************************************************************
 * Copyright (c) 2025 University of Utah
 * Copyright (c) 2025 University of Minnesota Duluth
 *
 * Copyright (c) 2025 Behnam Bozorgmehr
 * Copyright (c) 2025 Jeremy A. Gibbs
 * Copyright (c) 2025 Fabien Margairaz
 * Copyright (c) 2025 Eric R. Pardyjak
 * Copyright (c) 2025 Zachary Patterson
 * Copyright (c) 2025 Rob Stoll
 * Copyright (c) 2025 Lucas Ulmer
 * Copyright (c) 2025 Pete Willemsen
 *
 * This file is part of QES-Winds
 *
 * GPL-3.0 License
 *
 * QES-Winds is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * QES-Winds is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QES-Winds. If not, see <https://www.gnu.org/licenses/>.
 ****************************************************************************/

// Phase extraction of the QES float32 CPU kernels. Expressions and statement
// boundaries below deliberately retain the original arithmetic.
#include "solver.h"
#include "util/QESException.h"
#include <algorithm>
#include <cmath>
#include <math.h>

namespace dtcc_qes::solver {
template<> void SolverState<float>::build_rhs() {
  const auto *WGD = &*fields_;
  long icell_cent, icell_face;
#pragma omp parallel if(order_ == SweepOrder::RedBlack) private(icell_cent, icell_face) default(none) shared(WGD, R)
  {
#pragma omp for
    for (int k = 1; k < domain.nz() - 2; ++k) {
      for (int j = 0; j < domain.ny() - 1; ++j) {
        for (int i = 0; i < domain.nx() - 1; ++i) {
          // icell_cent = i + j * (WGD->nx - 1) + k * (WGD->nx - 1) * (WGD->ny - 1);
          icell_cent = domain.cell(i, j, k);
          // icell_face = i + j * WGD->nx + k * WGD->nx * WGD->ny;
          icell_face = domain.face(i, j, k);
          // Calculate divergence of initial velocity field
        // m/n already include 1/(dz * centre separation). Cancel only the
        // centre separation here, retaining 1/dz for the vertical divergence.
        R[icell_cent] = (-2.0f * pow(alpha1, 2.0))
                          * (((WGD->e[icell_cent] * WGD->u0[domain.faceAdd(icell_face, 1, 0, 0)]
                               - WGD->f[icell_cent] * WGD->u0[icell_face])
                              * domain.dx())
                             + ((WGD->g[icell_cent] * WGD->v0[domain.faceAdd(icell_face, 0, 1, 0)]
                                 - WGD->h[icell_cent] * WGD->v0[icell_face])
                                * domain.dy())
                             + ((WGD->m[icell_cent] * 0.5 * (domain.dz_array[k] + domain.dz_array[k + 1])
                                   * WGD->w0[domain.faceAdd(icell_face, 0, 0, 1)]
                                 - WGD->n[icell_cent] * 0.5f * (domain.dz_array[k] + domain.dz_array[k - 1])
                                     * WGD->w0[icell_face])));
        }
      }
    }
  }
}
template<> float SolverState<float>::sweep_lexicographic() {
  const auto *WGD = &*fields_;
  long icell_cent;
  float error, max_error = 0;
    int nonfinite = 0;

    //
    // main SOR formulation loop
    //
    for (int k = 1; k < domain.nz() - 2; ++k) {
      for (int j = 1; j < domain.ny() - 2; ++j) {
        for (int i = 1; i < domain.nx() - 2; ++i) {
          // icell_cent = i + j * (WGD->nx - 1) + k * (WGD->nx - 1) * (WGD->ny - 1);
          icell_cent = domain.cell(i, j, k);
          const float previous = lambda[icell_cent];
          const float next = (omega / (WGD->e[icell_cent] + WGD->f[icell_cent] + WGD->g[icell_cent] + WGD->h[icell_cent] + WGD->m[icell_cent] + WGD->n[icell_cent]))
                                 * (WGD->e[icell_cent] * lambda[domain.cellAdd(icell_cent, 1, 0, 0)]
                                    + WGD->f[icell_cent] * lambda[domain.cellAdd(icell_cent, -1, 0, 0)]
                                    + WGD->g[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 1, 0)]
                                    + WGD->h[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, -1, 0)]
                                    + WGD->m[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 0, 1)]
                                    + WGD->n[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 0, -1)] - R[icell_cent])
                               + (1.0f - omega) * lambda[icell_cent];// SOR formulation
          lambda[icell_cent] = next;
          error = fabs(next - previous);
          if (!std::isfinite(error)) nonfinite = 1;
          if (error > max_error) max_error = error;
        }
      }
    }

    // Mirror boundary condition (lambda (@k=0) = lambda (@k=1))
    for (int j = 0; j < domain.ny() - 1; ++j) {
      for (int i = 0; i < domain.nx() - 1; ++i) {
        // icell_cent = i + j * (WGD->nx - 1);// Lineralized index for cell centered values
        icell_cent = domain.cell(i, j, 0);
        lambda[icell_cent] = lambda[domain.cellAdd(icell_cent, 0, 0, 1)];
      }
    }


    if (nonfinite)
      throw qes::RuntimeError("Non-finite Lagrange multiplier change during solve");
  return max_error;
}
template<> float SolverState<float>::sweep_red_black() {
  const auto *WGD = &*fields_;
  long icell_cent, icell_face;
  float error, max_error = 0;
    max_error = 0.0f;
    int nonfinite = 0;

// Each cell is updated once; its pre-update value is its sweep-start value.
#pragma omp parallel private(icell_cent, icell_face, error) default(none) shared(WGD, lambda, R) reduction(max : max_error) reduction(| : nonfinite)
    {
      // main SOR formulation loop

      // Red nodes pass
#pragma omp for
      for (int k = 1; k < domain.nz() - 2; ++k) {
        for (int j = 1; j < domain.ny() - 2; ++j) {
          for (int i = 1; i < domain.nx() - 2; ++i) {

            if (((i + j + k) % 2) == 0) {
              // icell_cent = i + j * (WGD->nx - 1) + k * (WGD->nx - 1) * (WGD->ny - 1);
              icell_cent = domain.cell(i, j, k);
              const float previous = lambda[icell_cent];
              const float next = (omega / (WGD->e[icell_cent] + WGD->f[icell_cent] + WGD->g[icell_cent] + WGD->h[icell_cent] + WGD->m[icell_cent] + WGD->n[icell_cent]))
                                     * (WGD->e[icell_cent] * lambda[domain.cellAdd(icell_cent, 1, 0, 0)]
                                        + WGD->f[icell_cent] * lambda[domain.cellAdd(icell_cent, -1, 0, 0)]
                                        + WGD->g[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 1, 0)]
                                        + WGD->h[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, -1, 0)]
                                        + WGD->m[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 0, 1)]
                                        + WGD->n[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 0, -1)] - R[icell_cent])
                                   + (1.0f - omega) * lambda[icell_cent];// SOR formulation
              lambda[icell_cent] = next;
              error = fabs(next - previous);
              if (!std::isfinite(error)) nonfinite = 1;
              if (error > max_error) max_error = error;
            }
          }
        }
      }
      // end of omp for (with implicit barrier)

      // Black nodes pass
#pragma omp for
      for (int k = 1; k < domain.nz() - 2; ++k) {
        for (int j = 1; j < domain.ny() - 2; ++j) {
          for (int i = 1; i < domain.nx() - 2; ++i) {
            if (((i + j + k) % 2) == 1) {
              // icell_cent = i + j * (WGD->nx - 1) + k * (WGD->nx - 1) * (WGD->ny - 1);
              icell_cent = domain.cell(i, j, k);
              const float previous = lambda[icell_cent];
              const float next = (omega / (WGD->e[icell_cent] + WGD->f[icell_cent] + WGD->g[icell_cent] + WGD->h[icell_cent] + WGD->m[icell_cent] + WGD->n[icell_cent]))
                                     * (WGD->e[icell_cent] * lambda[domain.cellAdd(icell_cent, 1, 0, 0)]
                                        + WGD->f[icell_cent] * lambda[domain.cellAdd(icell_cent, -1, 0, 0)]
                                        + WGD->g[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 1, 0)]
                                        + WGD->h[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, -1, 0)]
                                        + WGD->m[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 0, 1)]
                                        + WGD->n[icell_cent] * lambda[domain.cellAdd(icell_cent, 0, 0, -1)] - R[icell_cent])
                                   + (1.0f - omega) * lambda[icell_cent];// SOR formulation
              lambda[icell_cent] = next;
              error = fabs(next - previous);
              if (!std::isfinite(error)) nonfinite = 1;
              if (error > max_error) max_error = error;
            }
          }
        }
      }
      // end of omp for (with implicit barrier)

      // Mirror boundary condition (lambda (@k=0) = lambda (@k=1))
#pragma omp for
      for (int j = 0; j < domain.ny() - 1; ++j) {
        for (int i = 0; i < domain.nx() - 1; ++i) {
          // icell_cent = i + j * (WGD->nx - 1);// Lineralized index for cell centered values
          icell_cent = domain.cell(i, j, 0);
          lambda[icell_cent] = lambda[domain.cellAdd(icell_cent, 0, 0, 1)];
        }
      }
      // end of omp for (with implicit barrier)

    }
    // end of omp parallel workshare
    // Exceptions must leave the parallel region on the calling thread.
    if (nonfinite)
      throw qes::RuntimeError("Non-finite Lagrange multiplier change during solve");
  return max_error;
}
template<> float SolverState<float>::corrected_face(int component,int i,int j,int k) const {
  const auto *WGD = &*fields_;
  const auto icell_cent = domain.cell(i,j,k), icell_face = domain.face(i,j,k);
  if (component == 0) return WGD->u0[icell_face]
                             + (1.0f / (2.0f * (float)pow(alpha1, 2.0))) * WGD->f[icell_cent] * domain.dx()
                                 * (lambda[icell_cent] - lambda[icell_cent - 1]);
  if (component == 1) return WGD->v0[icell_face]
                             + (1.0f / (2.0f * (float)pow(alpha1, 2.0))) * WGD->h[icell_cent] * domain.dy()
                                 * (lambda[icell_cent] - lambda[domain.cellAdd(icell_cent, 0, -1, 0)]);
  return WGD->w0[icell_face]
                             + (1.0f / (2.0f * (float)pow(alpha2, 2.0))) * WGD->n[icell_cent] * domain.dz_array[k]
                                 * (lambda[icell_cent] - lambda[domain.cellAdd(icell_cent, 0, 0, -1)]);
}
}
