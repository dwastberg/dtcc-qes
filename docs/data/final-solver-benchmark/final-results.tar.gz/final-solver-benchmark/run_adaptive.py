"""Finite final-wheel performance/reference comparison, with no policy tuning."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import numpy as np
from run_solver_policy_study import compare
from benchmark_prepared_wind import comparable,write


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'adaptive')
    args=ap.parse_args();out=args.output.resolve();out.mkdir(exist_ok=False)
    release=ROOT/'docs/data/solver-control-s9'
    manifest=json.loads((release/'manifest.json').read_text())
    assert hashlib.sha256((ROOT/'tools/validate_solver_policy.py').read_bytes()).hexdigest()==manifest['sources']['sources.tar.gz']['tools/validate_solver_policy.py']
    wheel=Path(json.loads((release/'validation.json').read_text())['checks']['artifacts']['wheel']['path'])
    expected=json.loads((release/'validation.json').read_text())['checks']['artifacts']['wheel']['sha256']
    assert hashlib.sha256(wheel.read_bytes()).hexdigest()==expected
    package=out/'package';package.mkdir()
    with zipfile.ZipFile(wheel) as archive:archive.extractall(package)
    shutil.copyfile(ROOT/'build/solver-control-s9/openmp-package/sitecustomize.py',package/'sitecustomize.py')
    evidence=ROOT/'docs/data/solver-control-s7'
    old=json.loads((evidence/'release-online-results.json').read_text())['rows']
    qualified={r['case']:r['qualified'] for r in json.loads((evidence/'all-reference-qualification.json').read_text())}
    templates=[r['request'] for r in old if r['request']['variant']=='adaptive' and r['request']['threads']==4 and qualified[r['request']['case']]]
    assert len(templates)==6
    rows=[]
    for rep in range(3):
        for template in templates:
            for variant in (['legacy','adaptive'] if rep%2==0 else ['adaptive','legacy']):
                rows.append(template|dict(variant=variant,rep=rep,id=f'final-{len(rows):02}'))
    write(out/'protocol.json',dict(rows=rows,worker_seconds=30,total_seconds=180,
        wheel_sha256=expected,policy_revision=json.loads((release/'scope.json').read_text())['policy']['native_revision'],
        source_inputs_manifest_sha256=hashlib.sha256((evidence/'manifest.json').read_bytes()).hexdigest(),
        reference='Existing frozen 2000-sweep float64 qualified same-grid reference; no new reference solve or retuning'))
    fixed=json.loads((evidence/'validation-fixed-results.json').read_text())['rows']
    completed=[];start=time.monotonic()
    for i,request in enumerate(rows):
        print(f"{i+1}/36 {request['case']} {request['variant']} rep={request['rep']}",flush=True)
        path=out/(request['id']+'.json')
        r=subprocess.run([sys.executable,str(ROOT/'tools/validate_solver_policy.py'),'--worker',str(evidence),
            '--request',json.dumps(request),'--package',str(package),'--output',str(path)],capture_output=True,text=True,
            timeout=30,env=os.environ|{'PYTHONPATH':str(package),'OMP_NUM_THREADS':'4','OMP_DYNAMIC':'FALSE','PYTHONDONTWRITEBYTECODE':'1'})
        path.with_suffix('.log').write_text(r.stdout+r.stderr);r.check_returncode()
        row=json.loads(path.read_text())
        original=next(v for v in old if v['request']['case']==request['case'] and v['request']['variant']==request['variant'] and v['request'].get('backend') is None)
        assert row['field_hashes']==original['field_hashes'] and row['diagnostics']==original['diagnostics']
        if request['variant']=='adaptive':
            assert row['control']['accepted'] and row['control']['actual_threads']==4
            assert row['control']['policy_revision']==json.loads((release/'scope.json').read_text())['policy']['native_revision']
            for k in ['assessment','assessment_history','checkpoint_history','method','monitor']:
                assert comparable(row['control'][k])==comparable(original['control'][k]),k
        ref=next(v for v in fixed if v['request']['case']==request['case'] and v['request']['purpose']=='reference' and v['request']['iterations']==2000)
        case=json.loads((evidence/f"cases/{request['case']}.json").read_text())
        with np.load(evidence/(ref['request']['id']+'.npz')) as a,np.load(path.with_suffix('.npz')) as b:
            error=compare(a['samples'][-1],b['samples'],row['plane_points'],case['speed'])
        target=all(h['maximum'] is not None and h['maximum']<=1e-3 and h['p95']<=5e-4 and h['required_valid'] and not h['validity_changes'] for h in error)
        assert target or request['variant']=='legacy'
        row.update(reference_errors=error,observable_target_passed=target,frozen_s7_fields_and_diagnostics_exact=True)
        completed.append(row);write(out/'results.json',dict(rows=completed))
        if time.monotonic()-start>180:raise TimeoutError('Adaptive benchmark matrix cap exhausted')
    groups=[]
    for template in templates:
        name=template['case'];versions={v:[r for r in completed if r['request']['case']==name and r['request']['variant']==v] for v in ['legacy','adaptive']}
        medians={v:statistics.median(r['api_seconds'] for r in values) for v,values in versions.items()}
        groups.append(dict(case=name,api_median_seconds=medians,speedup=medians['legacy']/medians['adaptive'],
            api_ranges={v:[min(r['api_seconds'] for r in values),max(r['api_seconds'] for r in values)] for v,values in versions.items()},
            iterations={v:sorted({r['diagnostics']['iterations'] for r in values}) for v,values in versions.items()},
            peak_rss_median_bytes={v:statistics.median(r['peak_rss_bytes'] for r in values) for v,values in versions.items()},
            max_vector_error_Uref=max(h['maximum'] for r in versions['adaptive'] for h in r['reference_errors']),
            all_adaptive_accepted=all(r['control']['accepted'] for r in versions['adaptive']),
            all_adaptive_targets_passed=all(r['observable_target_passed'] for r in versions['adaptive'])))
    write(out/'summary.json',dict(completed=len(completed),groups=groups,false_acceptances=sum(r['request']['variant']=='adaptive' and r['control']['accepted'] and not r['observable_target_passed'] for r in completed),
        all_frozen_s7_fields_and_diagnostics_exact=True,elapsed_seconds=time.monotonic()-start))
    print(json.dumps(groups,indent=2))


if __name__=='__main__':main()
