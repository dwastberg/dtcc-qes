"""Recompute final benchmark comparisons from immutable campaign outcomes."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from benchmark_prepared_wind import write


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def campaign(path):
    state=json.loads((path/'campaign.json').read_text())
    rows=[];comparisons=[]
    for folder in sorted(path.glob('run-*')):
        if not folder.is_dir():continue
        manifest=json.loads((folder/'manifest.json').read_text())
        for name,value in manifest['files'].items():assert sha(folder/name)==value,(folder,name)
        rows+=json.loads((folder/'summary.json').read_text())['results']
        comparisons+=json.loads((folder/'comparisons.json').read_text())['comparisons']
    assert state['status']=='completed' and len(rows)==state['expected_rows']
    assert all(r['status']=='completed' for r in rows)
    summary=[]
    for name,direction in sorted({(r['request']['case'],r['request']['direction']) for r in rows}):
        values={variant:[r for r in rows if r['request']['case']==name and r['request']['direction']==direction and r['request']['variant']==variant]
                for variant in ['baseline','disabled','bounded']}
        medians={k:statistics.median(r['timing']['api_seconds'] for r in group) for k,group in values.items()}
        pipelines={k:statistics.median(r['timing']['pipeline_seconds'] for r in group) for k,group in values.items()}
        memory={k:statistics.median(r['peak_rss_bytes'] for r in group) for k,group in values.items()}
        summary.append(dict(case=name,direction=direction,api_median_seconds=medians,pipeline_median_seconds=pipelines,
            peak_rss_median_bytes=memory,api_speedup={v:medians['baseline']/medians[v] for v in ['disabled','bounded']},
            pipeline_speedup={v:pipelines['baseline']/pipelines[v] for v in ['disabled','bounded']},
            memory_reduction_fraction={v:1-memory[v]/memory['baseline'] for v in ['disabled','bounded']},
            sweeps={v:sorted({r['diagnostics']['iterations'] for r in group}) for v,group in values.items()},
            converged={v:sum(r['diagnostics']['converged'] for r in group) for v,group in values.items()},
            stops={v:dict(Counter((r.get('control') or {}).get('termination_reason','legacy_tolerance' if r['diagnostics']['converged'] else 'iteration_limit') for r in group)) for v,group in values.items()}))
    return dict(output=str(path),workers=len(rows),summary=summary,comparison_count=len(comparisons),
        all_equal_work=all(c['same_completed_work'] for c in comparisons),all_equal_grids=all(c['same_grid'] for c in comparisons),
        all_bitwise_fields_equal=all(c['field_bitwise_equal'] for c in comparisons),
        source_ids=sorted({r['source_id'] for r in rows}),dependencies=[dict(version=v,revision=r) for v,r in sorted({(r['versions']['dtcc_core']['version'],r['versions']['dtcc_core']['revision']) for r in rows})])


def main():
    out=Path(__file__).resolve().parent
    paths=json.loads((out/'campaigns.json').read_text())
    results={name:campaign(ROOT/path) for name,path in paths.items()}
    adaptive=json.loads((out/'adaptive/summary.json').read_text())
    assert all(v['all_equal_work'] and v['all_equal_grids'] and v['all_bitwise_fields_equal'] for v in results.values())
    assert adaptive['completed']==36 and adaptive['false_acceptances']==0
    assert sum(v['workers'] for v in results.values())+adaptive['completed']==216
    write(out/'results.json',dict(campaigns=results,adaptive=adaptive,total_workers=216))
    lines=['# Final S9 solver benchmark','',
        'The frozen S9 solver is compared with corrected S1a (overall architecture) and S3 (immediate controls baseline). Three fresh-process repetitions, four actual OpenMP threads. Reported ratios use per-case/direction medians; no cross-resolution timing extrapolation.',
        '', 'Urban cases use 42–160 buildings. Equal-work field parity is not numerical/physical accuracy qualification. The adaptive comparison is confined to the six previously qualified S7 neighbourhood conditions.', '',
        '![Measured API times and control overhead](performance.png)','']
    for name,result in results.items():
        lines += ['## '+name,'',f"{result['workers']} workers; {result['comparison_count']} paired comparisons; all equal-work/grid/full-field checks pass.",'',
            '| Case / wind FROM | Baseline API s | S9 disabled s | S9 bounded s | Disabled speedup | Bounded speedup | RSS MiB baseline / disabled / bounded |',
            '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
        for r in result['summary']:
            t=r['api_median_seconds'];m=r['peak_rss_median_bytes']
            lines.append(f"| {r['case']} / {r['direction']:g}° | {t['baseline']:.3f} | {t['disabled']:.3f} | {t['bounded']:.3f} | {r['api_speedup']['disabled']:.2f}× | {r['api_speedup']['bounded']:.2f}× | {m['baseline']/2**20:.0f} / {m['disabled']/2**20:.0f} / {m['bounded']/2**20:.0f} |")
        lines+=['',f"Raw campaign: [{Path(result['output']).name}](../urban-benchmarks/{Path(result['output']).name}/results.json)",'']
    lines+=['## Qualified adaptive policy','',
        'The actual S9 wheel is imported without instrumentation. Legacy/adaptive worker order alternates by repetition. Fields and diagnostics match the frozen S7 results exactly, including under the currently installed DTCC Core revision. Existing float64 same-grid references assess both pedestrian heights and required receptors; no new scope is qualified.','',
        '| Condition | Legacy API s | Adaptive API s | Speedup | Legacy / adaptive sweeps | Max adaptive vector error / Uref |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for r in adaptive['groups']:
        t=r['api_median_seconds'];n=r['iterations']
        lines.append(f"| {r['case']} | {t['legacy']:.3f} | {t['adaptive']:.3f} | {r['speedup']:.2f}× | {n['legacy']} / {n['adaptive']} | {r['max_vector_error_Uref']:.3g} |")
    lines+=['',f"All 18 adaptive runs accepted and passed the existing observable target; {adaptive['false_acceptances']} false acceptances. All 36 adaptive/legacy outputs match their frozen S7 fields/diagnostics.",'',
        '## Findings','',
        'The overall 2 m / 2,000-sweep matrix demonstrates the architecture gain at realistic resolution and longer work, with exact full-field parity. Bounded runs also finish all 2,000 sweeps inside their declared 20 s native budgets. All large urban outputs retain iteration-limit stopping and unassessed accuracy.',
        '', 'The immediate S3 comparison is a separate 4 m / 500-sweep / 270° matrix. Disabled controls are approximately neutral in this current pilot; bounded execution adds monitoring/deadline overhead. This observation does not replace the historical S5 non-pass, its different confirmation matrix or its preserved timing evidence. No universal <=5% regression claim follows.',
        '', 'Peak RSS remains variable across fresh processes. In particular, the long-run slab-estate 315° baseline median is lower than the other slab directions; it is retained and lowers the reported memory-saving range. No outliers were removed.', '',
        '## Limits and reproduction','',
        'Full API time includes extraction, preparation, solve, finalization and NumPy output. Urban pipeline timings additionally include City construction, preview, sampling, hashing and compressed pedestrian-plane output; full-volume velocity/flags are compared via hashes rather than serialized in full. These and timing ranges remain in results.json/raw rows. RSS is process high-water, including imports and transient copies. Timings are local descriptive repetitions, not guarantees.',
        '', 'Legacy convergence remains a multiplier-change diagnostic. Large urban cases remain accuracy-unassessed even when equal-work fields are bitwise identical. Adaptive acceptance is restricted to the recorded ROI/receptors and supported numerical/build envelope; comfort/gust/physical qualification is outside this benchmark.',
        '', 'protocol.json records the finite worker matrix, source identities and current dependency revision. Every campaign preserves fresh fixtures, raw workers, logs and comparison manifests. Installed DTCC Core uses the live footprint-cleaning branch; both sides of every urban comparison use the same dependency revision. The frozen S9 solver sources and prior release evidence are unchanged.',
        '', '```sh','.venv/bin/python tools/run_urban_benchmarks.py --tier pilot --cache-dir build/solver-control-s9/campaign-cache',
        '.venv/bin/python tools/run_urban_benchmarks.py --tier core --iterations 2000 --solve-seconds 20 --cache-dir build/solver-control-s9/campaign-cache',
        '.venv/bin/python tools/run_urban_benchmarks.py --tier pilot --comparison controls --cache-dir build/solver-control-s9/campaign-cache',
        '.venv/bin/python build/final-solver-benchmark/run_adaptive.py --output build/final-adaptive-repeat','```','']
    (out/'report.md').write_text('\n'.join(lines))
    files={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file() and 'package' not in p.parts and 'mplconfig' not in p.parts and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='manifest.json'}
    write(out/'manifest.json',dict(files=files,prior_release_manifest_sha256=sha(ROOT/'docs/data/solver-control-s9/manifest.json')))
    print(out/'report.md')


if __name__=='__main__':main()
