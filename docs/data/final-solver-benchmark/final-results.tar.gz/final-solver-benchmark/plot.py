"""Plot only completed benchmark medians; no discarded timing observations."""
import json
import os
from pathlib import Path

OUT=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(OUT/'mplconfig')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

data=json.loads((OUT/'results.json').read_text())
fig=plt.figure(figsize=(14,11),layout='constrained')
grid=fig.add_gridspec(2,2,width_ratios=[1.25,1])
core=fig.add_subplot(grid[:,0]);adaptive=fig.add_subplot(grid[0,1]);controls=fig.add_subplot(grid[1,1])
colours=['#94a3b8','#0369a1','#0f766e']
names={'perimeter_neighbourhood':'Perimeter','mixed_downtown':'Downtown','slab_estate':'Slabs','industrial_residential':'Industrial'}
rows=data['campaigns']['overall-core-long']['summary'];y=np.arange(len(rows));h=.23
for i,(variant,label) in enumerate([('baseline','Corrected S1a'),('disabled','S9 controls disabled'),('bounded','S9 bounded')]):
    bars=core.barh(y+(i-1)*h,[r['api_median_seconds'][variant] for r in rows],height=h,color=colours[i],label=label)
    core.bar_label(bars,fmt='%.1f',padding=3,fontsize=8)
core.set_yticks(y,[names[r['case']]+f" {r['direction']:g}°" for r in rows]);core.invert_yaxis()
core.set_xlabel('Full wind.run API seconds (lower is faster)');core.set_xlim(0,15)
core.set_title('Urban neighbourhoods: 2 m, 2,000 sweeps\n42–160 buildings; identical equal-work full fields',loc='left',fontsize=12)
core.legend(loc='lower right',fontsize=9);core.grid(axis='x',alpha=.15);core.set_axisbelow(True)

rows=data['adaptive']['groups'];y=np.arange(len(rows))
labels=['Staggered 240°','Courtyards 315°','Mixed 195°','Staggered graded 150°','Courtyards 210° / 2 m/s','Courtyards 210° / 10 m/s']
for i,(variant,label) in enumerate([('legacy','S9 legacy'),('adaptive','S9 adaptive')]):
    bars=adaptive.barh(y+(i-.5)*.34,[r['api_median_seconds'][variant] for r in rows],height=.32,color=colours[i+1],label=label)
    adaptive.bar_label(bars,fmt='%.3f',padding=3,fontsize=8)
adaptive.set_yticks(y,labels,fontsize=9);adaptive.invert_yaxis();adaptive.set_xlabel('Full wind.run API seconds')
adaptive.set_title('Qualified pedestrian cases: actual release wheel\n18/18 adaptive runs accepted; zero false acceptances',loc='left',fontsize=12)
adaptive.set_xlim(0,max(r['api_median_seconds']['legacy'] for r in rows)*1.25)
adaptive.legend(fontsize=9);adaptive.grid(axis='x',alpha=.15);adaptive.set_axisbelow(True)

rows=data['campaigns']['controls-pilot']['summary'];y=np.arange(len(rows))
for i,(variant,label) in enumerate([('disabled','S9 controls disabled'),('bounded','S9 bounded')]):
    bars=controls.barh(y+(i-.5)*.34,[(1/r['api_speedup'][variant]-1)*100 for r in rows],height=.32,color=colours[i+1],label=label)
    controls.bar_label(bars,fmt='%.1f%%',padding=3,fontsize=9)
controls.set_yticks(y,[names[r['case']] for r in rows]);controls.invert_yaxis();controls.axvline(0,color='#475569',lw=.8)
controls.set_xlabel('API time change from corrected S3 (%)');controls.set_xlim(-5,24)
controls.set_title('Immediate controls comparison: 4 m, 500 sweeps\nSeparate matrix; historical S5 non-pass remains recorded',loc='left',fontsize=12)
controls.grid(axis='x',alpha=.15);controls.set_axisbelow(True)
for ax in [core,adaptive,controls]:
    ax.spines[['top','right']].set_visible(False)
fig.suptitle('Final S9 benchmark — 216 fresh-process workers, four OpenMP threads\nPer-condition medians of three repetitions; numerical scope remains restricted',fontsize=15)
fig.savefig(OUT/'performance.png',dpi=180)
fig.savefig(OUT/'performance.svg')
print(OUT/'performance.png')
