"""Urban morphology, frozen geometry, strict sampling and comparison semantics."""
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import pytest
from shapely.geometry import Point, Polygon
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
try:
    import urban_wind_cases as cases
    import benchmark_urban_wind as benchmark
finally:
    sys.path.pop(0)


@pytest.mark.parametrize('name',cases.NAMES)
def test_neighbourhoods_are_repeatable_disjoint_and_have_open_receptors(name,tmp_path):
    case=cases.make_case(name)
    assert case==cases.make_case(name)
    assert len(case['buildings'])>=40 and len({b['height'] for b in case['buildings']})>=5
    polygons=[Polygon(b['vertices']) for b in case['buildings']]
    for i,p in enumerate(polygons):
        assert p.is_valid and p.area>0
        assert all(p.distance(q)>0 for q in polygons[i+1:])
    occupied=unary_union(polygons)
    assert all(occupied.distance(Point(p))>=3 for p in case['receptors'])
    path=tmp_path/'case.json';cases.write_case(case,path)
    assert path.with_suffix('.svg').exists()
    assert json.loads(path.read_text())==case


def test_probe_instrumentation_preserves_all_existing_statements(tmp_path):
    runner=tmp_path/'src/qes_core/dtcc/wind_runner.cpp';runner.parent.mkdir(parents=True)
    binding=tmp_path/'src/cpp/bindings.cpp';binding.parent.mkdir(parents=True)
    runner.write_text('original numerical statements\n');binding.write_text('module {\n  m.doc() = "old";\n}\n')
    old=runner.read_text();benchmark.instrument_team_probe(tmp_path)
    assert runner.read_text().startswith(old)
    assert '  m.doc() = "old";' in binding.read_text()
    with pytest.raises(ValueError,match='already instrumented'): benchmark.instrument_team_probe(tmp_path)


def test_comparison_reports_support_changes_and_never_claims_reference_accuracy(tmp_path):
    rows=[]
    for i,variant in enumerate(('baseline','disabled','bounded')):
        request=dict(id=str(i),case='urban',direction=270,repeat=0,variant=variant,speed=5)
        rows.append(dict(status='completed',request=request,grid_sha256={'x':'same'},shape=[2,2,2],
            diagnostics={'iterations':2 if variant=='bounded' else 8},timing={'api_seconds':1},field_sha256={'v':variant}))
        data={}
        for n in (0,1):
            data[f'velocity{n}']=np.full((2,2,3),i,dtype=float)
            data[f'valid{n}']=np.ones((2,2),bool)
            if variant=='bounded': data[f'valid{n}'][0,0]=False
        np.savez(tmp_path/f'{i}.npz',**data)
    benchmark.write(tmp_path/'summary.json',{'results':rows})
    benchmark.analyze(tmp_path)
    result=json.loads((tmp_path/'comparisons.json').read_text())
    assert all(r['reference_qualification']=='not_assessed' for r in result['comparisons'])
    bounded=result['comparisons'][1]
    assert not bounded['same_completed_work'] and bounded['planes'][0]['validity_changes']==1
    assert bounded['planes'][0]['common_valid']==3
