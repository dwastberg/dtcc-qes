// Conservative flux arithmetic extracted from dtcc/divergence.cpp. GPL-3.0.
#pragma once
#include "solver.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace dtcc_qes::solver {
template<class FaceValue> MassDiagnostics mass_diagnostics(const PoissonOperator &data,
    const std::vector<int> &flags, FaceValue face, MassRegion region = {}) {
  const auto &d = data.domain;
  const int nx = d.nx()-1, ny = d.ny()-1, nz = d.nz()-2;
  if (region.i_last == -1) region.i_last = nx-1;
  if (region.j_last == -1) region.j_last = ny-1;
  if (region.k_last == -1) region.k_last = nz-1;
  if (region.i_first < 1 || region.i_last > nx-1 || region.i_last < region.i_first
      || region.j_first < 1 || region.j_last > ny-1 || region.j_last < region.j_first
      || region.k_first < 0 || region.k_last > nz-1 || region.k_last < region.k_first)
    throw std::invalid_argument("Mass diagnostic region is outside the assessed cells");
  const double dx = d.dx(), dy = d.dy();
  MassDiagnostics stats;
  double weighted_square = 0, volume_sum = 0;
  for (int k = region.k_first+1; k < region.k_last+1; ++k)
    for (int j = region.j_first; j < region.j_last; ++j)
      for (int i = region.i_first; i < region.i_last; ++i) {
        const auto c = d.cell(i,j,k);
        if (flags[c] == 0 || flags[c] == 2) continue;
        const double ue = face(0,i+1,j,k), uw = face(0,i,j,k);
        const double vn = face(1,i,j+1,k), vs = face(1,i,j,k);
        const double wt = face(2,i,j,k+1), wb = face(2,i,j,k);
        for (const double value : {ue, uw, vn, vs, wt, wb})
          if (!std::isfinite(value)) throw std::runtime_error("Non-finite face velocity in divergence diagnostic");
        const auto a = data.stencil(c,k);
        const double dz = d.dz_array[k], volume = dx * dy * dz;
        const double east = a.e * dx * dx, west = a.f * dx * dx;
        const double north = a.g * dy * dy, south = a.h * dy * dy;
        const double above = a.m * dz * 0.5 * (dz + d.dz_array[k + 1]);
        const double below = a.n * dz * 0.5 * (dz + d.dz_array[k - 1]);
        const double net = (east * ue - west * uw) * dy * dz
                         + (north * vn - south * vs) * dx * dz
                         + (above * wt - below * wb) * dx * dy;
        const double divergence = net / volume;
        if (!std::isfinite(divergence)) throw std::runtime_error("Non-finite conservative divergence");
        if (k == nz - 1) {
          stats.top_band_max = std::max(stats.top_band_max, std::abs(divergence));
          ++stats.top_band_cells;
        } else {
          stats.interior_max = std::max(stats.interior_max, std::abs(divergence));
          weighted_square += volume * divergence * divergence;
          volume_sum += volume;
          ++stats.cells;
        }
      }
  if (stats.cells) stats.interior_rms = std::sqrt(weighted_square / volume_sum);
  return stats;
}
}
