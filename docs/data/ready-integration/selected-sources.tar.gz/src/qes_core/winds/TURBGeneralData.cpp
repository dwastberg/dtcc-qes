#include "../dtcc/api/turbulence_reference.h"
/****************************************************************************
 * Copyright (c) 2025 University of Utah
 * Copyright (c) 2025 University of Minnesota Duluth
 *
 * Copyright (c) 2025 Behnam Bozorgmehr
 * Copyright (c) 2025 Jeremy A. Gibbs
 * Copyright (c) 2025 Fabien Margairaz
 * Copyright (c) 2025 Eric R. Pardyjak
 * Copyright (c) 2025 Zachary Patterson
 * Copyright (c) 2025 Rob Stoll
 * Copyright (c) 2025 Lucas Ulmer
 * Copyright (c) 2025 Pete Willemsen
 *
 * This file is part of QES-Winds
 *
 * GPL-3.0 License
 *
 * QES-Winds is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * QES-Winds is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QES-Winds. If not, see <https://www.gnu.org/licenses/>.
 ****************************************************************************/

/**
 * @file TURBGeneralData.cpp
 * @brief :document this:
 */


#include "util/QESLog.h"
#include "TURBGeneralData.h"
#include "util/QESException.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <sstream>

TURBGeneralData::TURBGeneralData(const TurbulenceConfig &config, WINDSGeneralData *WGD)
  : domain(WGD->domain)
{

  auto StartTime = std::chrono::high_resolution_clock::now();
  qes::log::info() << "-------------------------------------------------------------------" << std::endl;
  qes::log::info() << "[QES-TURB]\t Initialization of turbulence model...\n";
  m_WGD = WGD;

  const int method = config.methodLocalMixing;
  if (method != 0 && method != 1) {
    std::ostringstream message;
    message << "Unsupported turbulence mixing-length method: " << method;
    throw qes::InputError(message.str());
  }
  // Flat ground: no terrain raises the 15 m rotation reference.
  const float terrain_top = 0.0f;
  if (domain.z_face.back() < 15.0f + terrain_top) {
    std::ostringstream message;
    message << "Turbulence domain top must reach at least " << 15.0f + terrain_top
            << " m for the 15 m rotation reference";
    throw qes::InputError(message.str());
  }

  allocateMemory();

  // local copies of trubulence parameters
  turbUpperBound = config.turbUpperBound;

  if (config.sigConst) {
    Vector3Float sigConst;
    sigConst = *(config.sigConst);

    sigUOrg = sigConst[0];
    sigVOrg = sigConst[1];
    sigWOrg = sigConst[2];

    sigUConst = 1.5f * sigUOrg * sigUOrg * cPope * cPope;
    sigVConst = 1.5f * sigVOrg * sigVOrg * cPope * cPope;
    sigWConst = 1.5f * sigWOrg * sigWOrg * cPope * cPope;
  }

  flagNonLocalMixing = config.flagNonLocalMixing;
  if (flagNonLocalMixing) {
    qes::log::info() << "[QES-TURB]\t Non-Local mixing for buidlings: ON \n";
  }

  if (config.verticalStretching > 0) {
    flagUniformZGrid = false;
  }

  backgroundMixing = config.backgroundMixing;

  /*
     vector containing cell id of fluid cell
     do not include 1 cell shell around the domain
     => i=1...nx-2 j=1...ny-2
     do not include 1 cell layer at the top of the domain
     => k=1...nz-2
  */
  for (int k = 1; k < domain.nz() - 2; k++) {
    for (int j = 1; j < domain.ny() - 2; j++) {
      for (int i = 1; i < domain.nx() - 2; i++) {
        // int id = i + j * (nx - 1) + k * (nx - 1) * (ny - 1);
        long id = domain.cell(i, j, k);
        if (m_WGD->icellflag[id] != 0 && m_WGD->icellflag[id] != 2) {
          icellfluid.push_back(id);
          iturbflag.at(id) = 1;
        }
      }
    }
  }


  // definition of the solid wall for loglaw
  qes::log::info() << "[QES-TURB]\t Defining Solid Walls...\n";
  wallVec.push_back(std::make_unique<TURBWallBuilding>(config, m_WGD, this));
  wallVec.push_back(std::make_unique<TURBWallTerrain>(config, m_WGD, this));
  // qes::log::info() << "\t\t Walls Defined...\n";

  // mixing length

  qes::log::info() << "[QES-TURB]\t Defining Local Mixing Length...\n";
  auto mlStartTime = std::chrono::high_resolution_clock::now();
  if (config.methodLocalMixing == 0) {
    qes::log::info() << "[QES-TURB]\t Default Local Mixing Length...\n";
    localMixing = std::make_unique<LocalMixingDefault>();
  } else if (config.methodLocalMixing == 1) {
    qes::log::info() << "[QES-TURB]\t Computing Local Mixing Length using serial code...\n";
    localMixing = std::make_unique<LocalMixingSerial>();
  }

  localMixing->defineMixingLength(config, m_WGD);

  // make a copy as mixing length will be modify by non-local
  // (need to be reset at each time instances)
  for (int cellId : icellfluid) {
    Lm[cellId] = vonKar * m_WGD->mixingLengths[cellId];
  }

  auto mlEndTime = std::chrono::high_resolution_clock::now();
  std::chrono::duration<double> mlElapsed = mlEndTime - mlStartTime;
  qes::log::info() << "[QES-TURB]\t Local Mixing Defined: elapsed time: " << mlElapsed.count() << " s\n";

  // Caluclating Turbulence quantities (u*,z0,d0) based on morphology of domain.
  bldgH_mean = 0.0;
  bldgH_max = 0.0;
  terrainH_max = 0.0;
  zRef = 0.0;
  uRef = 0.0;
  uStar = 0.0;

  qes::log::info() << "[QES-TURB]\t Calculating Morphometric parametrization of trubulence..." << std::endl;

  terrainH_max = 0.0;

  // qes::log::info() << "\t\t max terrain height = "<< terrainH_max << std::endl;

  // dtcc-qes: shared float32 morphometric arithmetic; coordinate/scalar only.
  std::vector<float> heights;
  for (const auto *building : m_WGD->allBuildingsV) heights.push_back(building->H);
  const auto reference = dtcc_qes::turbulence_reference(std::move(heights), config.site_z0);
  bldgH_mean = reference.mean_height;
  bldgH_max = reference.maximum_height;
  z0d = reference.roughness_length;
  d0d = reference.displacement_height;
  zRef = reference.reference_height;

  qes::log::info() << "[QES-TURB]\t Computing friction velocity..." << std::endl;
  frictionVelocity();

  auto EndTime = std::chrono::high_resolution_clock::now();
  std::chrono::duration<double> Elapsed = EndTime - StartTime;

  qes::log::info() << "[QES-TURB]\t Initialization of turbulence model completed.\n";
  qes::log::info() << "\t\t elapsed time: " << Elapsed.count() << " s" << endl;
}



TURBGeneralData::TURBGeneralData(WINDSGeneralData *WGD)
  : domain(WGD->domain)
{
  qes::log::info() << "-------------------------------------------------------------------" << std::endl;
  qes::log::info() << "[QES-TURB]\t Initialization of turbulence model...\n";
  m_WGD = WGD;

  allocateMemory();

  /*
     vector containing cell id of fluid cell
     do not include 1 cell shell around the domain
     => i=1...nx-2 j=1...ny-2
     do not include 1 cell layer at the top of the domain
     => k=1...nz-2
  */
  for (int k = 1; k < domain.nz() - 2; k++) {
    for (int j = 1; j < domain.ny() - 2; j++) {
      for (int i = 1; i < domain.nx() - 2; i++) {
        // int id = i + j * (nx - 1) + k * (nx - 1) * (ny - 1);
        long id = domain.cell(i, j, k);
        if (m_WGD->icellflag[id] != 0 && m_WGD->icellflag[id] != 2) {
          icellfluid.push_back(id);
        }
      }
    }
  }
}

void TURBGeneralData::allocateMemory()
{
  qes::log::info() << "[QES-TURB]\t Allocating memory..." << std::flush;

  long numcell_cent = domain.numCellCentered();

  // logic variable
  iturbflag.resize(numcell_cent, 0);

  // local mixing length
  Lm.resize(numcell_cent, 0.0);

  // comp. of the velocity gradient tensor
  Gxx.resize(numcell_cent, 0);
  Gxy.resize(numcell_cent, 0);
  Gxz.resize(numcell_cent, 0);
  Gyx.resize(numcell_cent, 0);
  Gyy.resize(numcell_cent, 0);
  Gyz.resize(numcell_cent, 0);
  Gzx.resize(numcell_cent, 0);
  Gzy.resize(numcell_cent, 0);
  Gzz.resize(numcell_cent, 0);

  // comp of the stress tensor
  txx.resize(numcell_cent, 0);
  txy.resize(numcell_cent, 0);
  txz.resize(numcell_cent, 0);
  tyy.resize(numcell_cent, 0);
  tyz.resize(numcell_cent, 0);
  tzz.resize(numcell_cent, 0);

  // derived turbulence quantities
  tke.resize(numcell_cent, 0);
  CoEps.resize(numcell_cent, 0);
  nuT.resize(numcell_cent, 0);
  // qes::log::info() << "\t\t Memory allocation completed.\n";

  // comp of the divergence of the stress tensor
  tmp_dtoxdx.resize(numcell_cent, 0);
  tmp_dtoydy.resize(numcell_cent, 0);
  tmp_dtozdz.resize(numcell_cent, 0);

  // comp of the divergence of the stress tensor
  div_tau_x.resize(numcell_cent, 0);
  div_tau_y.resize(numcell_cent, 0);
  div_tau_z.resize(numcell_cent, 0);

}


// compute turbulence fields
void TURBGeneralData::run()
{

  auto StartTime = std::chrono::high_resolution_clock::now();
  qes::log::info() << "-------------------------------------------------------------------" << std::endl;
  qes::log::info() << "[QES-TURB]\t Running turbulence model..." << std::endl;

  qes::log::info() << "[QES-TURB]\t Computing friction velocity..." << std::endl;
  frictionVelocity();

  qes::log::info() << "[QES-TURB]\t Computing Derivatives (Strain Rate)..." << std::endl;
  derivativeVelocity();
  // qes::log::info()<<"\t\t Derivatives computed."<<std::endl;

  qes::log::info() << "[QES-TURB]\t Computing local mixing length model..." << std::endl;
  getTurbulentViscosity();

  qes::log::info() << "[QES-TURB]\t Computing Stess Tensor..." << std::endl;
  stressTensor();
  // qes::log::info()<<"\t\t Stress Tensor computed."<<std::endl;

  if (flagNonLocalMixing) {
    qes::log::info() << "[QES-TURB]\t Applying non-local mixing..." << std::endl;

    for (size_t i = 0; i < m_WGD->allBuildingsV.size(); i++) {
      m_WGD->allBuildingsV[m_WGD->building_id[i]]->NonLocalMixing(m_WGD, this, m_WGD->building_id[i]);
    }
    // qes::log::info()<<"\t\t Non-local mixing completed."<<std::endl;
  }

  qes::log::info() << "[QES-TURB]\t Checking Upper Bound of Turbulence Fields..." << std::endl;
  boundTurbFields();

  if (backgroundMixing > 0.0) {
    addBackgroundMixing();
  }

  if (flagCompDivStress) {
    divergenceStress();
  }

  auto EndTime = std::chrono::high_resolution_clock::now();
  std::chrono::duration<double> Elapsed = EndTime - StartTime;

  qes::log::info() << "[QES-TURB] \t Turbulence model completed.\n";
  qes::log::info() << "\t\t elapsed time: " << Elapsed.count() << " s" << endl;
}

void TURBGeneralData::frictionVelocity()
{
  // The lower-bound face identifies the reference cell. That cell and its
  // upper w face must both exist, including when zRef is in the top cell.
  const auto reference = std::lower_bound(domain.z_face.begin(), domain.z_face.end(), zRef);
  const auto reference_index = reference - domain.z_face.begin();
  if (reference == domain.z_face.end() || reference_index > domain.nz() - 2) {
    std::ostringstream message;
    message << "Turbulence reference height " << zRef
            << " m has no sampleable layer below domain top " << domain.z_face.back() << " m";
    throw qes::InputError(message.str());
  }
  const int k = static_cast<int>(reference_index);
  float nVal = 0.0, uSum = 0.0;
  for (int j = 0; j < domain.ny() - 1; j++) {
    for (int i = 0; i < domain.nx() - 1; i++) {
      // int cellID = i + j * (nx - 1) + k * (nx - 1) * (ny - 1);
      // int faceID = i + j * (nx) + k * (nx) * (ny);
      long cellID = domain.cell(i, j, k);
      long faceID = domain.face(i, j, k);
      if (m_WGD->icellflag[cellID] != 0 && m_WGD->icellflag[cellID] != 2) {
        /*uSum += sqrt(pow(0.5 * (m_WGD->u[faceID] + m_WGD->u[faceID + 1]), 2)
                     + pow(0.5 * (m_WGD->v[faceID] + m_WGD->v[faceID + nx]), 2)
                     + pow(0.5 * (m_WGD->w[faceID] + m_WGD->w[faceID + nx * ny]), 2));*/
        uSum += sqrt(pow(0.5 * (m_WGD->u[domain.face(i, j, k)] + m_WGD->u[domain.face(i + 1, j, k)]), 2)
                     + pow(0.5 * (m_WGD->v[domain.face(i, j, k)] + m_WGD->v[domain.face(i, j + 1, k)]), 2)
                     + pow(0.5 * (m_WGD->w[domain.face(i, j, k)] + m_WGD->w[domain.face(i, j, k + 1)]), 2));
        nVal++;
      }
    }
  }
  uRef = uSum / nVal;

  uStar = 0.4 * uRef / log((zRef - d0d) / z0d);
  qes::log::info() << "[QES-TURB]\t Mean reference velocity at zRef = " << zRef << " m ==> uRef = " << uRef << " m/s" << std::endl;
  qes::log::info() << "[QES-TURB]\t Mean friction velocity uStar = " << uStar << " m/s" << std::endl;
}

void TURBGeneralData::derivativeVelocity()
{
  qes::log::info() << "[QES-TURB]\t Computing Velocity Derivatives..." << std::endl;
  for (int cellID : icellfluid) {
    // linearized index: cellID = i + j*(nx-1) + k*(nx-1)*(ny-1);
    //  i,j,k -> inverted linearized index
    // int k = (int)(cellID / ((nx - 1) * (ny - 1)));
    // int j = (int)((cellID - k * (nx - 1) * (ny - 1)) / (nx - 1));
    // int i = cellID - j * (nx - 1) - k * (nx - 1) * (ny - 1);
    // int faceID = i + j * nx + k * nx * ny;
    auto [i, j, k] = domain.getCellIdx(cellID);
    // long faceID = domain.face(i, j, k);

    // - Diagonal componants of the velocity gradient tensor naturally fall at the cell-center
    // - Off-diagonal componants of the  velocity gradient tensor require extra interpolation
    //   of the velocity field to get the derivative at the cell-center
    // - Derivative with respect to z need to be adjusted for non-uniform z-grid


    // Gxx = dudx
    Gxx[cellID] = (m_WGD->u[domain.face(i + 1, j, k)] - m_WGD->u[domain.face(i, j, k)]) / (domain.dx());
    // Gyx = dvdx
    Gyx[cellID] = ((m_WGD->v[domain.face(i + 1, j, k)] + m_WGD->v[domain.face(i + 1, j + 1, k)])
                   - (m_WGD->v[domain.face(i - 1, j, k)] + m_WGD->v[domain.face(i - 1, j + 1, k)]))
                  / (4.0f * domain.dx());
    // Gzx = dwdx
    Gzx[cellID] = ((m_WGD->w[domain.face(i + 1, j, k)] + m_WGD->w[domain.face(i + 1, j, k + 1)])
                   - (m_WGD->w[domain.face(i - 1, j, k)] + m_WGD->w[domain.face(i - 1, j, k + 1)]))
                  / (4.0f * domain.dx());

    // Gxy = dudy
    Gxy[cellID] = ((m_WGD->u[domain.face(i, j + 1, k)] + m_WGD->u[domain.face(i + 1, j + 1, k)])
                   - (m_WGD->u[domain.face(i, j - 1, k)] + m_WGD->u[domain.face(i + 1, j - 1, k)]))
                  / (4.0f * domain.dy());
    // Gyy = dvdy
    Gyy[cellID] = (m_WGD->v[domain.face(i, j + 1, k)] - m_WGD->v[domain.face(i, j, k)]) / (domain.dy());
    // Gzy = dwdy
    Gzy[cellID] = ((m_WGD->w[domain.face(i, j + 1, k)] + m_WGD->w[domain.face(i, j + 1, k + 1)])
                   - (m_WGD->w[domain.face(i, j - 1, k)] + m_WGD->w[domain.face(i, j - 1, k + 1)]))
                  / (4.0f * domain.dy());


    if (flagUniformZGrid) {
      // Gxz = dudz
      Gxz[cellID] = ((m_WGD->u[domain.face(i, j, k + 1)] + m_WGD->u[domain.face(i + 1, j, k + 1)])
                     - (m_WGD->u[domain.face(i, j, k - 1)] + m_WGD->u[domain.face(i + 1, j, k - 1)]))
                    / (4.0f * domain.dz());
      // Gyz = dvdz
      Gyz[cellID] = ((m_WGD->v[domain.face(i, j, k + 1)] + m_WGD->v[domain.face(i, j + 1, k + 1)])
                     - (m_WGD->v[domain.face(i, j, k - 1)] + m_WGD->v[domain.face(i, j + 1, k - 1)]))
                    / (4.0f * domain.dz());
      // Gzz = dwdz
      Gzz[cellID] = (m_WGD->w[domain.face(i, j, k + 1)] - m_WGD->w[domain.face(i, j, k)]) / (domain.dz());
    } else {
      // Gxz = dudz
      Gxz[cellID] = (0.5f * (domain.z[k] - domain.z[k - 1]) / (domain.z[k + 1] - domain.z[k])
                       * ((m_WGD->u[domain.face(i, j, k + 1)] + m_WGD->u[domain.face(i + 1, j, k + 1)])
                          - (m_WGD->u[domain.face(i, j, k)] + m_WGD->u[domain.face(i + 1, j, k)]))
                     + 0.5f * (domain.z[k + 1] - domain.z[k]) / (domain.z[k] - domain.z[k - 1])
                         * ((m_WGD->u[domain.face(i, j, k)] + m_WGD->u[domain.face(i + 1, j, k)])
                            - (m_WGD->u[domain.face(i, j, k - 1)] + m_WGD->u[domain.face(i + 1, j, k - 1)])))
                    / (domain.z[k + 1] - domain.z[k - 1]);
      // Gyz = dvdz
      Gyz[cellID] = (0.5f * (domain.z[k] - domain.z[k - 1]) / (domain.z[k + 1] - domain.z[k])
                       * ((m_WGD->v[domain.face(i, j, k + 1)] + m_WGD->v[domain.face(i, j + 1, k + 1)])
                          - (m_WGD->v[domain.face(i, j, k)] + m_WGD->v[domain.face(i, j + 1, k)]))
                     + 0.5f * (domain.z[k + 1] - domain.z[k]) / (domain.z[k] - domain.z[k - 1])
                         * ((m_WGD->v[domain.face(i, j, k)] + m_WGD->v[domain.face(i, j + 1, k)])
                            - (m_WGD->v[domain.face(i, j, k - 1)] + m_WGD->v[domain.face(i, j + 1, k - 1)])))
                    / (domain.z[k + 1] - domain.z[k - 1]);
      // Gzz = dwdz
      Gzz[cellID] = (m_WGD->w[domain.face(i, j, k + 1)] - m_WGD->w[domain.face(i, j, k)]) / (domain.dz_array[k]);
    }
  }

  // qes::log::info() << "[QES-TURB]\t Imposing Wall BC (log law)..." << std::endl;
  for (auto &wall : wallVec) {
    wall->setWallsVelocityDeriv(m_WGD, this);
  }
  // qes::log::info()<<"\t\t Wall BC done."<<std::endl;
}

void TURBGeneralData::getTurbulentViscosity()
{
  float tkeBound = turbUpperBound * uStar * uStar;

  for (int cellID : icellfluid) {

    float Sxx = Gxx[cellID];
    float Syy = Gyy[cellID];
    float Szz = Gzz[cellID];
    float Sxy = 0.5 * (Gxy[cellID] + Gyx[cellID]);
    float Sxz = 0.5 * (Gxz[cellID] + Gzx[cellID]);
    float Syz = 0.5 * (Gyz[cellID] + Gzy[cellID]);

    float NU_T = 0.0;
    float TKE = 0.0;
    float LM = Lm[cellID];

    //
    float SijSij = Sxx * Sxx + Syy * Syy + Szz * Szz + 2.0 * (Sxy * Sxy + Sxz * Sxz + Syz * Syz);

    NU_T = LM * LM * sqrt(2.0 * SijSij);
    TKE = pow((NU_T / (cPope * LM)), 2.0);

    if (production_observer) production_observer(cellID,NU_T,TKE);

    if (TKE > tkeBound)
      TKE = tkeBound;

    nuT[cellID] = NU_T;
    CoEps[cellID] = 5.7 * pow(sqrt(TKE) * cPope, 3.0) / (LM);
    tke[cellID] = TKE;
  }
}

std::array<double, 2> TURBGeneralData::rotationDirection(int i, int j)
{
  const float height = 15.0f + m_WGD->terrain[domain.cell2d(i, j)];
  const int reference = static_cast<int>(std::lower_bound(domain.z_face.begin(), domain.z_face.end(), height)
                                         - domain.z_face.begin());
  std::array<double, 2> direction;
  const auto sample = [&](int k) {
    // The top face has no cell flag: candidates must be physical cell levels.
    if (k < 1 || k > domain.nz() - 2) return false;
    const int flag = m_WGD->icellflag[domain.cell(i, j, k)];
    if (flag == 0 || flag == 2) return false;
    const double u = m_WGD->u[domain.face(i, j, k)], v = m_WGD->v[domain.face(i, j, k)];
    const double speed = std::hypot(u, v);
    if (!std::isfinite(speed) || speed == 0) return false;
    direction = {u / speed, v / speed};
    return true;
  };
  if (sample(reference)) return direction;

  ++rotationFallbackColumns;
  // Horizontal velocities live at z cell centres. Select alternatives by
  // those heights, retaining the original reference index when it is usable.
  // Nearest fluid centre wins; prefer the higher level on a tie.
  int above = static_cast<int>(std::lower_bound(domain.z.begin() + 1, domain.z.end(), height)
                               - domain.z.begin());
  int below = above - 1;
  while (above <= domain.nz() - 2 || below >= 1) {
    const bool higher = above <= domain.nz() - 2
      && (below < 1 || domain.z[above] - height <= height - domain.z[below]);
    const int candidate = higher ? above++ : below--;
    if (sample(candidate)) return direction;
  }
  // No measured horizontal direction exists in this column (e.g. calm wind).
  // The fixed x axis keeps zero stresses finite and is explicitly diagnosed.
  return {1.0, 0.0};
}

void TURBGeneralData::stressTensor()
{
  float tkeBound = turbUpperBound * uStar * uStar;
  rotationFallbackColumns = 0;
  const double nan = std::numeric_limits<double>::quiet_NaN();
  std::vector<std::array<double, 2>> directions(
    (domain.nx() - 1) * (domain.ny() - 1), {nan, nan});

  double R11, R12, R13, R21, R22, R23, R31, R32, R33;// rotation matrix
  double I11, I12, I13, I21, I22, I23, I31, I32, I33;// inverse of rotation matrix
  double P11, P12, P13, P21, P22, P23, P31, P32, P33;// P = tau*inv(R)

  for (int cellID : icellfluid) {
    // int k = (int)(cellID / ((nx - 1) * (ny - 1)));
    // int j = (int)((cellID - k * (nx - 1) * (ny - 1)) / (nx - 1));
    // int i = cellID - j * (nx - 1) - k * (nx - 1) * (ny - 1);
    // int faceID = i + j * nx + k * nx * ny;
    auto [i, j, k] = domain.getCellIdx(cellID);
    long faceID = domain.face(i, j, k);

    float Sxx = Gxx[cellID];
    float Syy = Gyy[cellID];
    float Szz = Gzz[cellID];
    float Sxy = 0.5 * (Gxy[cellID] + Gyx[cellID]);
    float Sxz = 0.5 * (Gxz[cellID] + Gzx[cellID]);
    float Syz = 0.5 * (Gyz[cellID] + Gzy[cellID]);

    // float NU_T = 0.0;
    // float TKE = 0.0;
    float NU_T = nuT[cellID];
    float TKE = tke[cellID];
    float LM = Lm[cellID];

    //
    float SijSij = Sxx * Sxx + Syy * Syy + Szz * Szz + 2.0 * (Sxy * Sxy + Sxz * Sxz + Syz * Syz);

    // NU_T = LM * LM * sqrt(2.0 * SijSij);
    // TKE = pow((NU_T / (cPope * LM)), 2.0);

    if (TKE > tkeBound)
      TKE = tkeBound;

    CoEps[cellID] = 5.7 * pow(sqrt(TKE) * cPope, 3.0) / (LM);
    // tke[cellID] = TKE;

    txx[cellID] = (2.0 / 3.0) * TKE - 2.0 * (NU_T * Sxx);
    tyy[cellID] = (2.0 / 3.0) * TKE - 2.0 * (NU_T * Syy);
    tzz[cellID] = (2.0 / 3.0) * TKE - 2.0 * (NU_T * Szz);
    txy[cellID] = -2.0 * (NU_T * Sxy);
    txz[cellID] = -2.0 * (NU_T * Sxz);
    tyz[cellID] = -2.0 * (NU_T * Syz);

    if (stress_observer) stress_observer(0,cellID,
      {txx[cellID],txy[cellID],txz[cellID],tyy[cellID],tyz[cellID],tzz[cellID]});

    auto &direction = directions[domain.cell2d(i, j)];
    if (!std::isfinite(direction[0])) direction = rotationDirection(i, j);
    const auto [c, s] = direction;
    if (orientation_observer) orientation_observer(cellID,c,s);

    // Q has columns (streamwise, crosswind, vertical) in Cartesian coordinates.
    // Wind-aligned stress is Q^T * tau * Q, so R = Q^T here.
    R11 = c;
    R12 = s;
    R13 = 0.0;
    R21 = -s;
    R22 = c;
    R23 = 0.0;
    R31 = 0.0;
    R32 = 0.0;
    R33 = 1.0;

    I11 = R11;
    I12 = R21;
    I13 = R31;
    I21 = R12;
    I22 = R22;
    I23 = R32;
    I31 = R13;
    I32 = R23;
    I33 = R33;

    double txx_temp = txx[cellID];
    double txy_temp = txy[cellID];
    double txz_temp = txz[cellID];
    double tyy_temp = tyy[cellID];
    double tyz_temp = tyz[cellID];
    double tzz_temp = tzz[cellID];

    // Orthogonal inverse is the transpose: I = Q.
    matMult(txx_temp, txy_temp, txz_temp, txy_temp, tyy_temp, tyz_temp, txz_temp, tyz_temp, tzz_temp, I11, I12, I13, I21, I22, I23, I31, I32, I33, P11, P12, P13, P21, P22, P23, P31, P32, P33);

    matMult(R11, R12, R13, R21, R22, R23, R31, R32, R33, P11, P12, P13, P21, P22, P23, P31, P32, P33, txx_temp, txy_temp, txz_temp, txy_temp, tyy_temp, tyz_temp, txz_temp, tyz_temp, tzz_temp);

    txx_temp = fabs(sigUConst * txx_temp);
    tyy_temp = fabs(sigVConst * tyy_temp);
    tzz_temp = fabs(sigWConst * tzz_temp);


    // Return to Cartesian coordinates: Q * tau_wind * Q^T.
    R11 = c;
    R12 = -s;
    R13 = 0.0;
    R21 = s;
    R22 = c;
    R23 = 0;
    R31 = 0;
    R32 = 0;
    R33 = 1;

    I11 = R11;
    I12 = R21;
    I13 = R31;
    I21 = R12;
    I22 = R22;
    I23 = R32;
    I31 = R13;
    I32 = R23;
    I33 = R33;

    matMult(txx_temp, txy_temp, txz_temp, txy_temp, tyy_temp, tyz_temp, txz_temp, tyz_temp, tzz_temp, I11, I12, I13, I21, I22, I23, I31, I32, I33, P11, P12, P13, P21, P22, P23, P31, P32, P33);

    matMult(R11, R12, R13, R21, R22, R23, R31, R32, R33, P11, P12, P13, P21, P22, P23, P31, P32, P33, txx_temp, txy_temp, txz_temp, txy_temp, tyy_temp, tyz_temp, txz_temp, tyz_temp, tzz_temp);

    txx[cellID] = txx_temp;
    txy[cellID] = txy_temp;
    txz[cellID] = txz_temp;
    tyy[cellID] = tyy_temp;
    tyz[cellID] = tyz_temp;
    tzz[cellID] = tzz_temp;
    if (stress_observer) stress_observer(1,cellID,
      {txx[cellID],txy[cellID],txz[cellID],tyy[cellID],tyz[cellID],tzz[cellID]});
  }
}

void TURBGeneralData::matMult(const double &A11,
                              const double &A12,
                              const double &A13,
                              const double &A21,
                              const double &A22,
                              const double &A23,
                              const double &A31,
                              const double &A32,
                              const double &A33,
                              const double &B11,
                              const double &B12,
                              const double &B13,
                              const double &B21,
                              const double &B22,
                              const double &B23,
                              const double &B31,
                              const double &B32,
                              const double &B33,
                              double &C11,
                              double &C12,
                              double &C13,
                              double &C21,
                              double &C22,
                              double &C23,
                              double &C31,
                              double &C32,
                              double &C33)

{
  C11 = A11 * B11 + A12 * B21 + A13 * B31;
  C12 = A11 * B12 + A12 * B22 + A13 * B32;
  C13 = A11 * B13 + A12 * B23 + A13 * B33;
  C21 = A21 * B11 + A22 * B21 + A23 * B31;
  C22 = A21 * B12 + A22 * B22 + A23 * B32;
  C23 = A21 * B13 + A22 * B23 + A23 * B33;
  C31 = A31 * B11 + A32 * B21 + A33 * B31;
  C32 = A31 * B12 + A32 * B22 + A33 * B32;
  C33 = A31 * B13 + A32 * B23 + A33 * B33;
}


void TURBGeneralData::addBackgroundMixing()
{
  for (int cellID : icellfluid) {
    txx[cellID] += backgroundMixing * backgroundMixing;
    tyy[cellID] += backgroundMixing * backgroundMixing;
    tzz[cellID] += backgroundMixing * backgroundMixing;
  }
}

void TURBGeneralData::divergenceStress()
{
  qes::log::info() << "[QES-TURB]\t Computing Divergence of Stess Tensor..." << std::endl;

  // x-comp of the divergence of the stress tensor
  // div(tau)_x = dtxxdx + dtxydy + dtxzdz
  derivativeStress(txx, txy, txz, div_tau_x);

  // y-comp of the divergence of the stress tensor
  // div(tau)_y = dtxzdx + dtyydy + dtyzdz
  derivativeStress(txy, tyy, tyz, div_tau_y);

  // z-comp of the divergence of the stress tensor
  // div(tau)_z = dtxzdx + dtyzdy + dtzzdz
  derivativeStress(txz, tyz, tzz, div_tau_z);
}

void TURBGeneralData::derivativeStress(const std::vector<float> &tox,
                                       const std::vector<float> &toy,
                                       const std::vector<float> &toz,
                                       std::vector<float> &div_tau_o)
{
  // o-comp of the divergence of the stress tensor
  for (int cellID : icellfluid) {
    // linearized index
    auto [i, j, k] = domain.getCellIdx(cellID);

    tmp_dtoxdx[cellID] = (tox[domain.cellAdd(cellID, 1, 0, 0)] - tox[domain.cellAdd(cellID, -1, 0, 0)]) / (2.0f * domain.dx());
    tmp_dtoydy[cellID] = (toy[domain.cellAdd(cellID, 0, 1, 0)] - toy[domain.cellAdd(cellID, 0, -1, 0)]) / (2.0f * domain.dy());

    if (flagUniformZGrid) {
      tmp_dtozdz[cellID] = (toz[domain.cellAdd(cellID, 0, 0, 1)] - toz[domain.cellAdd(cellID, 0, 0, -1)])
                           / (2.0f * domain.dz());
    } else {
      tmp_dtozdz[cellID] = ((domain.z[k] - domain.z[k - 1]) / (domain.z[k + 1] - domain.z[k])
                              * (toz[domain.cellAdd(cellID, 0, 0, 1)] - toz[cellID])
                            + (domain.z[k + 1] - domain.z[k]) / (domain.z[k] - domain.z[k - 1])
                                * (toz[cellID] - toz[domain.cellAdd(cellID, 0, 0, -1)]))
                           / (domain.z[k + 1] - domain.z[k - 1]);
    }
  }
  // correction at the wall
  for (auto &wall : wallVec) {
    wall->setWallsStressDeriv(m_WGD, this, tox, toy, toz);
  }
  // compute the divergence
  for (int cellID : icellfluid) {
    div_tau_o[cellID] = tmp_dtoxdx[cellID] + tmp_dtoydy[cellID] + tmp_dtozdz[cellID];
  }
}

void TURBGeneralData::boundTurbFields()
{
  float stressBound = turbUpperBound * uStar * uStar;
  for (int cellID : icellfluid) {
    if (txx[cellID] < -stressBound)
      txx[cellID] = -stressBound;
    if (txx[cellID] > stressBound)
      txx[cellID] = stressBound;
  }
  for (int cellID : icellfluid) {
    if (txy[cellID] < -stressBound)
      txy[cellID] = -stressBound;
    if (txy[cellID] > stressBound)
      txy[cellID] = stressBound;
  }
  for (int cellID : icellfluid) {
    if (txz[cellID] < -stressBound)
      txz[cellID] = -stressBound;
    if (txz[cellID] > stressBound)
      txz[cellID] = stressBound;
  }
  for (int cellID : icellfluid) {
    if (tyy[cellID] < -stressBound)
      tyy[cellID] = -stressBound;
    if (tyy[cellID] > stressBound)
      tyy[cellID] = stressBound;
  }
  for (int cellID : icellfluid) {
    if (tyz[cellID] < -stressBound)
      tyz[cellID] = -stressBound;
    if (tyz[cellID] > stressBound)
      tyz[cellID] = stressBound;
  }
  for (int cellID : icellfluid) {
    if (tzz[cellID] < -stressBound)
      tzz[cellID] = -stressBound;
    if (tzz[cellID] > stressBound)
      tzz[cellID] = stressBound;
    if (stress_observer) stress_observer(2,cellID,
      {txx[cellID],txy[cellID],txz[cellID],tyy[cellID],tyz[cellID],tzz[cellID]});
  }
}
