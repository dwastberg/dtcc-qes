// QES-derived workspace and phase driver; GPL-3.0-or-later.
#include "solver.h"
#include "mass_diagnostics.h"
#include "winds/WINDSGeneralData.h"
#include "util/QESException.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <type_traits>

namespace dtcc_qes::solver {
PoissonOperator::PoissonOperator(const WINDSGeneralData &wind)
  : domain(wind.domain), e(wind.e), f(wind.f), g(wind.g), h(wind.h), m(wind.m), n(wind.n) {
  for (const auto *a : {&e,&f,&g,&h,&m,&n})
    if (a->size() != std::size_t(domain.numCellCentered())
        || !std::all_of(a->begin(),a->end(),[](float x) { return std::isfinite(x); }))
      throw qes::InputError("Solver coefficients must have the expected length and finite values");
}
ConditionInputs::ConditionInputs(const WINDSGeneralData &wind)
  : domain(wind.domain),u0(wind.u0),v0(wind.v0),w0(wind.w0),icellflag(wind.icellflag) {}
FaceDestination::FaceDestination(WINDSGeneralData &wind) : u(wind.u),v(wind.v),w(wind.w) {}

template<class Real> SolverState<Real>::SolverState(const PoissonOperator &op,
    double tolerance, SweepOrder order, float relaxation)
  : operator_(op),domain(op.domain),tolerance_(std::is_same_v<Real,float> ? double(float(tolerance)) : tolerance),
    order_(order),omega(Real(relaxation)) {
  if (!std::isfinite(tolerance_) || tolerance_ < std::numeric_limits<Real>::epsilon())
    throw qes::InputError("Solver tolerance must be finite and at least the arithmetic epsilon");
  if (order != SweepOrder::Lexicographic && order != SweepOrder::RedBlack)
    throw qes::InputError("Invalid CPU sweep order");
  if (!std::isfinite(relaxation) || relaxation <= 0 || relaxation >= 2)
    throw qes::InputError("Relaxation must be finite and between zero and two");
  R.resize(domain.numCellCentered(),0);
  lambda.resize(domain.numCellCentered(),0);
  if constexpr (std::is_same_v<Real,float>) lambda_old.resize(domain.numCellCentered(),0);
}

template<class Real> void SolverState<Real>::begin(ConditionInputs input, int sweeps, StopRule rule) {
  phase_ = Phase::Failed;
  fields_.reset();
  if (sweeps < 1 || (rule != StopRule::LegacyTolerance && rule != StopRule::FixedSweeps))
    throw qes::InputError("A positive total sweep limit and valid stop rule are required");
  if (input.domain.getDomainCellNum() != domain.getDomainCellNum() || input.domain.dx() != domain.dx()
      || input.domain.dy() != domain.dy() || input.domain.dz_array != domain.dz_array)
    throw qes::InputError("Solver and wind-field domains differ");
  for (const auto *a : {&input.u0,&input.v0,&input.w0})
    if (a->size() != std::size_t(domain.numFaceCentered())
        || !std::all_of(a->begin(),a->end(),[](float x) { return std::isfinite(x); }))
      throw qes::InputError("Initial wind arrays must have the expected length and finite values");
  if (input.icellflag.size() != std::size_t(domain.numCellCentered()))
    throw qes::InputError("Condition cell flags have the wrong length");
  std::fill(R.begin(),R.end(),Real(0));
  std::fill(lambda.begin(),lambda.end(),Real(0));
  std::fill(lambda_old.begin(),lambda_old.end(),Real(0));
  iterations_ = 0; last_change_ = 0; total_sweeps_ = sweeps; stop_rule_ = rule;
  fields_.emplace(KernelFields{operator_.e,operator_.f,operator_.g,operator_.h,operator_.m,operator_.n,
                             input.u0,input.v0,input.w0,input.icellflag});
  try { build_rhs(); phase_ = Phase::Active; }
  catch (...) { fields_.reset(); throw; }
}

template<class Real> void SolverState<Real>::require_iterate() const {
  if (!fields_ || (phase_ != Phase::Active && phase_ != Phase::Finalized))
    throw qes::InputError("Begin a valid condition before accessing solver state");
}
template<class Real> SolveDiagnostics SolverState<Real>::diagnostics() const {
  require_iterate();
  return {iterations_,double(last_change_),tolerance_,iterations_ > 0 && std::isfinite(last_change_)
          && last_change_ <= tolerance_};
}
template<class Real> Termination SolverState<Real>::termination() const {
  require_iterate();
  if (stop_rule_ == StopRule::LegacyTolerance && diagnostics().converged) return Termination::LegacyTolerance;
  if (iterations_ == total_sweeps_) return stop_rule_ == StopRule::FixedSweeps ? Termination::FixedBudget : Termination::IterationLimit;
  return Termination::None;
}
template<class Real> WorkReport SolverState<Real>::advance(int sweeps) {
  require_iterate();
  if (phase_ != Phase::Active || sweeps < 0)
    throw qes::InputError("Advance requires an active condition and nonnegative work");
  const int before = iterations_;
  const int work = std::min(sweeps,total_sweeps_-iterations_);
  try {
    for (int i = 0; i < work && termination() == Termination::None; ++i) {
      last_change_ = order_ == SweepOrder::RedBlack ? sweep_red_black() : sweep_lexicographic();
      ++iterations_;
    }
  } catch (...) { phase_ = Phase::Failed; fields_.reset(); throw; }
  return {iterations_-before,diagnostics(),termination()};
}
template<class Real> bool SolverState<Real>::solid(int i,int j,int k) const {
  if (i < 0 || i >= domain.nx()-1 || j < 0 || j >= domain.ny()-1 || k < 1 || k >= domain.nz()-1) return false;
  const auto flag = fields_->icellflag[domain.cell(i,j,k)];
  return flag == 0 || flag == 2;
}
template<class Real> float SolverState<Real>::face_value(int component,int i,int j,int k) const {
  // Match the original face-owned mask, including the excluded ground ghost.
  if (k >= 1 && (solid(i,j,k) || solid(i-(component==0),j-(component==1),k-(component==2)))) return 0;
  if (k >= 1 && k < domain.nz()-2 && i >= 1 && i < domain.nx()-1 && j >= 1 && j < domain.ny()-1)
    return corrected_face(component,i,j,k);
  const auto f = domain.face(i,j,k);
  return component == 0 ? fields_->u0[f] : component == 1 ? fields_->v0[f] : fields_->w0[f];
}

// The same collocation expression is used for pure observation and full output.
template<class FaceValue> static void centers(const qes::Domain &domain, const std::vector<int> &flags,
    LayerRange layers, CenteredDestination out, FaceValue face) {
  const int nx = domain.nx()-1, ny = domain.ny()-1;
  if (layers.first < 0 || layers.last < layers.first || layers.last > domain.nz()-2)
    throw qes::InputError("Observation layers are outside the physical grid");
  const auto count = std::size_t(layers.last-layers.first)*ny*nx;
  out.velocity.resize(count*3); out.cell_flags.resize(count);
  for (int k = layers.first+1; k <= layers.last; ++k)
    for (int j = 0; j < ny; ++j) for (int i = 0; i < nx; ++i) {
      const auto c = (std::size_t(k-1-layers.first)*ny+j)*nx+i;
      out.velocity[3*c] = 0.5f * (face(0,i+1,j,k) + face(0,i,j,k));
      out.velocity[3*c+1] = 0.5f * (face(1,i,j+1,k) + face(1,i,j,k));
      out.velocity[3*c+2] = 0.5f * (face(2,i,j,k+1) + face(2,i,j,k));
      out.cell_flags[c] = flags[domain.cell(i,j,k)];
    }
}
template<class Real> Observation SolverState<Real>::observe(LayerRange layers) const {
  require_iterate();
  Observation result{layers,domain.nx()-1,domain.ny()-1,{}, {}};
  centers(domain,fields_->icellflag,layers,{result.velocity,result.cell_flags},
          [&](int c,int i,int j,int k) { return face_value(c,i,j,k); });
  return result;
}
template<class Real> MassDiagnostics SolverState<Real>::diagnose(MassRegion region) const {
  require_iterate();
  return mass_diagnostics(operator_,fields_->icellflag,
      [&](int c,int i,int j,int k) { return face_value(c,i,j,k); },region);
}
template<class Real> void SolverState<Real>::finalize(FaceDestination out, std::optional<CenteredDestination> centered,
                                                     MassDiagnostics *final_mass) {
  require_iterate();
  if (!iterations_) throw qes::InputError("Finalize requires at least one complete sweep");
  const auto immutable = [&](const std::vector<float> &a) {
    return &a == &fields_->u0 || &a == &fields_->v0 || &a == &fields_->w0
        || &a == &operator_.e || &a == &operator_.f || &a == &operator_.g
        || &a == &operator_.h || &a == &operator_.m || &a == &operator_.n;
  };
  if (immutable(out.u) || immutable(out.v) || immutable(out.w)
      || (centered && (immutable(centered->velocity) || &centered->velocity == &out.u
          || &centered->velocity == &out.v || &centered->velocity == &out.w
          || static_cast<const void *>(&centered->cell_flags) == static_cast<const void *>(&fields_->icellflag))))
    throw qes::InputError("Finalization destinations must not alias immutable solver inputs");
  if (&out.u == &out.v || &out.u == &out.w || &out.v == &out.w)
    throw qes::InputError("Finalization face destinations must not alias each other");
  try {
    const auto count = std::size_t(domain.numFaceCentered());
    out.u.resize(count); out.v.resize(count); out.w.resize(count);
#pragma omp parallel for if(order_ == SweepOrder::RedBlack)
    for (int k = 0; k < domain.nz(); ++k)
      for (int j = 0; j < domain.ny(); ++j) for (int i = 0; i < domain.nx(); ++i) {
        const auto f = domain.face(i,j,k);
        out.u[f] = face_value(0,i,j,k); out.v[f] = face_value(1,i,j,k); out.w[f] = face_value(2,i,j,k);
      }
    if constexpr (std::is_same_v<Real,double>)
      for (const auto *a : {&out.u,&out.v,&out.w})
        if (!std::all_of(a->begin(),a->end(),[](float x) { return std::isfinite(x); }))
          throw qes::RuntimeError("Non-finite corrected velocity during solve");
    if (centered) centers(domain,fields_->icellflag,{0,domain.nz()-2},*centered,
        [&](int c,int i,int j,int k) { const auto f = domain.face(i,j,k); return c == 0 ? out.u[f] : c == 1 ? out.v[f] : out.w[f]; });
    // The final caller already needs these complete faces. Read them directly
    // for its global diagnostic instead of reconstructing all six again.
    if (final_mass) *final_mass = mass_diagnostics(operator_,fields_->icellflag,
        [&](int c,int i,int j,int k) { const auto f = domain.face(i,j,k); return c == 0 ? out.u[f] : c == 1 ? out.v[f] : out.w[f]; });
    phase_ = Phase::Finalized;
  } catch (...) { phase_ = Phase::Failed; fields_.reset(); throw; }
}
template<class Real> std::size_t SolverState<Real>::workspace_bytes() const {
  return (R.size()+lambda.size()+lambda_old.size())*sizeof(Real);
}
template<class Real> StudyState<Real> SolverState<Real>::copy_state_for_study() const {
  require_iterate();
  return {lambda,lambda_old,R};
}

template class SolverState<float>;
template class SolverState<double>;
}
