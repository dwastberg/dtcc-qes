"""Unit checks for the native build parity harness (the builds themselves are not run)."""

import importlib.util
import io
from pathlib import Path
import tarfile

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("compare_native_builds", ROOT / "tools/compare_native_builds.py")
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)


def save(path, **values):
    np.savez(path, _module=np.array(str(path)), **values)
    return path


def test_identical_results_ignore_module_path(tmp_path):
    a = save(tmp_path / "a.npz", v=np.arange(4, dtype=np.float32))
    b = save(tmp_path / "b.npz", v=np.arange(4, dtype=np.float32))
    assert harness.compare_results(a, b) == ([], 1)


def test_bit_dtype_shape_and_key_differences_are_reported(tmp_path):
    v = np.array([0.0, 1.0], dtype=np.float32)
    a = save(tmp_path / "a.npz", bits=v, dtype=v, shape=v, only_a=v)
    b = save(tmp_path / "b.npz", bits=np.array([-0.0, 1.0], dtype=np.float32), dtype=v.astype(np.float64),
             shape=v.reshape(2, 1), only_b=v)
    problems, _ = harness.compare_results(a, b)
    assert problems == ["only in one result: only_a", "only in one result: only_b",
                        "differs: bits", "differs: dtype", "differs: shape"]


def test_store_flattens_nested_results():
    out = {}
    harness.store(out, "case", dict(velocity=np.zeros(3), diagnostics=dict(iterations=5), turbulence=None))
    assert set(out) == {"case/velocity", "case/scalars", "case/diagnostics/scalars"}
    assert str(out["case/diagnostics/scalars"]) == '{"iterations": 5}'


def test_s0_provenance_exception_is_narrow_and_opt_in(tmp_path):
    key = "public/case/metadata/versions/native_build/scalars"
    a = save(tmp_path / "a.npz", **{key: np.array('{"openmp_enabled": true}')})
    b = save(tmp_path / "b.npz", **{key: np.array('{"fp_contract": "on", "openmp_enabled": true}')})
    assert harness.compare_results(a, b)[0]
    assert not harness.compare_results(a, b, allow_added_contraction=True)[0]
    b = save(tmp_path / "b.npz", **{key: np.array('{"fp_contract": "on", "openmp_enabled": false}')})
    assert harness.compare_results(a, b, allow_added_contraction=True)[0]


def test_backend_pair_keeps_numerical_diagnostics_strict(tmp_path):
    def record(backend, enabled, iterations):
        out = {}
        harness.store(out, "public/case", dict(metadata=dict(model=dict(backend=backend),
            versions=dict(native_build=dict(openmp_enabled=enabled, fp_contract="on"))),
            diagnostics=dict(iterations=iterations)))
        return out
    a = save(tmp_path / "a.npz", **record("serial CPU", False, 10))
    b = save(tmp_path / "b.npz", **record("OpenMP CPU", True, 10))
    assert not harness.compare_results(a, b, backend_pair=True)[0]
    b = save(tmp_path / "b.npz", **record("OpenMP CPU", True, 11))
    assert harness.compare_results(a, b, backend_pair=True)[0] == ["differs: public/case/diagnostics/scalars"]


def source_archive(path, names):
    with tarfile.open(path, 'w:gz') as archive:
        for name in names:
            info = tarfile.TarInfo(name)
            info.size = 1
            archive.addfile(info, io.BytesIO(b'\n'))
    return path


def test_source_archive_identity_and_cache(tmp_path):
    path = source_archive(tmp_path/'sources.tar.gz',
                          ['CMakeLists.txt', 'pyproject.toml', 'src/qes_core/CMakeLists.txt'])
    first = harness.export_archive(path, tmp_path/'work')
    assert first == harness.export_archive(path, tmp_path/'work')
    assert first[2].startswith('sha256:') and len(first[2]) == 71
    path = source_archive(path, ['CMakeLists.txt', 'pyproject.toml', 'src/qes_core/CMakeLists.txt', 'new.cpp'])
    assert harness.export_archive(path, tmp_path/'work') != first


def test_incomplete_and_escaping_source_archives_are_rejected(tmp_path):
    path = source_archive(tmp_path/'sources.tar.gz', ['CMakeLists.txt'])
    with pytest.raises(ValueError, match='omits pyproject.toml'):
        harness.export_archive(path, tmp_path/'work')
    source_archive(path, ['../../escaped.txt'])
    with pytest.raises(tarfile.FilterError):
        harness.export_archive(path, tmp_path/'work')
    assert not (tmp_path/'escaped.txt').exists()
