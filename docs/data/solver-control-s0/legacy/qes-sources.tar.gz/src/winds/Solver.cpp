/****************************************************************************
 * Copyright (c) 2025 University of Utah
 * Copyright (c) 2025 University of Minnesota Duluth
 *
 * Copyright (c) 2025 Behnam Bozorgmehr
 * Copyright (c) 2025 Jeremy A. Gibbs
 * Copyright (c) 2025 Fabien Margairaz
 * Copyright (c) 2025 Eric R. Pardyjak
 * Copyright (c) 2025 Zachary Patterson
 * Copyright (c) 2025 Rob Stoll
 * Copyright (c) 2025 Lucas Ulmer
 * Copyright (c) 2025 Pete Willemsen
 *
 * This file is part of QES-Winds
 *
 * GPL-3.0 License
 *
 * QES-Winds is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * QES-Winds is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QES-Winds. If not, see <https://www.gnu.org/licenses/>.
 ****************************************************************************/

/**
 * @file Solver.cpp
 * @brief Declares and defines variables required for both solvers.
 *
 * An abstract class that is the basis for the windfield convergence algorithm and
 * contains information needed to run the simulation as well as functions widely
 * used by different solver methods. There are several special member variables that
 * should be accesible to all solvers. They are declared in this class.
 *
 * @sa CPUSolver
 * @sa DynamicParallelism
 * @sa GlobalMemory
 * @sa SharedMemory
 */


#include "util/QESLog.h"
#include "Solver.h"

// duplication of this macro
#define CELL(i, j, k, w) ((i) + (j) * (nx + (w)) + (k) * (nx + (w)) * (ny + (w)))

#define PBSTR "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"
#define PBWIDTH 60


/**
 * Shows progress of the solving process by printing the percentage.
 */


/**
 * Assigns values read by WINDSInputData to variables
 * used in the solvers.
 *
 * @note this is only meant to work with QES-Winds!
 *
 * @param WID :document this:
 * @param WGD :document this:
 */
Solver::Solver(qes::Domain domain_in, const float &tolerance)
  : domain(std::move(domain_in)),
    alpha1(1),
    alpha2(1),
    eta(pow((alpha1 / alpha2), 2.0)),
    A(pow((domain.dx() / domain.dy()), 2.0)),
    B(eta * pow((domain.dx() / domain.dz()), 2.0))

{
  if (!std::isfinite(tolerance) || tolerance < std::numeric_limits<float>::epsilon())
    throw qes::InputError("Solver tolerance must be finite and at least float epsilon");
  tol = tolerance;

  lambda.resize(domain.numCellCentered(), 0.0);
  lambda_old.resize(domain.numCellCentered(), 0.0);
  R.resize(domain.numCellCentered(), 0.0);
}

void Solver::validateSolve(const WINDSGeneralData *WGD, int iterations) const
{
  if (!WGD || iterations < 1)
    throw qes::InputError("A prepared wind field and a positive iteration limit are required");
  if (WGD->domain.getDomainCellNum() != domain.getDomainCellNum()
      || WGD->domain.dx() != domain.dx() || WGD->domain.dy() != domain.dy()
      || WGD->domain.dz_array != domain.dz_array)
    throw qes::InputError("Solver and wind-field domains differ");
  for (const auto *values : {&WGD->u0, &WGD->v0, &WGD->w0}) {
    if (values->size() != static_cast<size_t>(domain.numFaceCentered()))
      throw qes::InputError("Initial wind arrays have the wrong length");
    if (!std::all_of(values->begin(), values->end(), [](float x) { return std::isfinite(x); }))
      throw qes::InputError("Initial wind arrays must be finite");
  }
  for (const auto *values : {&WGD->e, &WGD->f, &WGD->g, &WGD->h, &WGD->m, &WGD->n}) {
    if (values->size() != static_cast<size_t>(domain.numCellCentered()))
      throw qes::InputError("Solver coefficient arrays have the wrong length");
    if (!std::all_of(values->begin(), values->end(), [](float x) { return std::isfinite(x); }))
      throw qes::InputError("Solver coefficients must be finite");
  }
}
