import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
from compare_native_builds import evaluate,compare_results,stage_package
from qualify_reference_integration import compare_impact
r=Path.cwd();b=r/'build/reference-integration';old=Path('/private/tmp/dtcc-qes-ready-integration')
source=old/'build/ready-integration/qualified-serial'
for line in (source/'solver-policy-identity.txt').read_text().splitlines()[1:]:
 name,sha=line.rsplit(' ',1);assert hashlib.sha256((old/name).read_bytes()).hexdigest()==sha,name
stage_package(old,next(source.glob('_qes*.so')),b/'main-serial-package')
rows=[];outputs={}
for backend in ('openmp','serial'):
 for threads in ((1,2,4,8) if backend=='openmp' else (1,)):
  for label,package in (('main',b/('main-package' if backend=='openmp' else 'main-serial-package')),('candidate',b/(f'qualified-{backend}-package'))):
   dest=b/f'{label}-{backend}-{threads}.npz';count=evaluate(package,dest,threads)
   assert count==429
   outputs[label,backend,threads]=dest
  report=compare_impact(outputs['main',backend,threads],outputs['candidate',backend,threads]);assert report['passed'],report['differences']
  rows.append(dict(backend=backend,threads=threads,kind='main_impact',**report))
  print(backend,threads,'main impact passes',flush=True)
for threads in (1,2,4,8):
 for kind,a,c,backend_pair in [('threads',outputs['candidate','openmp',1],outputs['candidate','openmp',threads],False),('backend',outputs['candidate','serial',1],outputs['candidate','openmp',threads],True)]:
  differences,count=compare_results(a,c,backend_pair=backend_pair);assert not differences,differences
  rows.append(dict(kind=kind,threads=threads,records=count,differences=differences))
report=dict(passed=True,cases_per_run=429,rows=rows)
(b/'matrix-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('All thread/backend comparisons pass',flush=True)
