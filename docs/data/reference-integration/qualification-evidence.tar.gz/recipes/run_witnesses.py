import sys,os,subprocess
from pathlib import Path
b=Path.cwd()/'build/reference-integration'
for name in ('A','E-after'):
 for arm in ('main','candidate'):
  package=b/('main-package' if arm=='main' else 'qualified-openmp-package')
  with (b/(f'witness-{name}-{arm}.log')).open('w') as log:
   subprocess.run([sys.executable,str(b/'capture_witness.py'),name,arm],check=True,stdout=log,stderr=subprocess.STDOUT,env=os.environ|dict(PYTHONPATH=str(package)+':'+str(Path.cwd()/'validation'),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',DTCC_QES_AIJ_DATA='/Users/dagwastberg/repos/dtcc/dtcc-qes/validation'),timeout=180)
  print(name,arm,'captured',flush=True)
