import os,sys,subprocess,json
from pathlib import Path
import numpy as np
b=Path.cwd()/'build/reference-integration';rows=[]
for n in range(3):
 for label in (('main','candidate') if n%2==0 else ('candidate','main')):
  package=b/('main-package' if label=='main' else 'qualified-openmp-package');dest=b/f'cost-{n}-{label}.json'
  subprocess.run([sys.executable,'tools/feature_merge_baseline.py','--api','new','--costs',str(dest)],check=True,stdout=subprocess.DEVNULL,env=os.environ|dict(PYTHONPATH=str(package),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1'))
  rows.append(dict(round=n,arm=label,path=str(dest),result=json.loads(dest.read_text())))
summary={}
for category in ('wind-only','combined','export'):
 samples={arm:[s for r in rows if r['arm']==arm for s in r['result']['measurements'][category]['seconds']] for arm in ('main','candidate')}
 med={a:float(np.median(s)) for a,s in samples.items()};delta=med['candidate']-med['main']
 summary[category]=dict(samples=samples,medians=med,relative_change=delta/med['main'],absolute_change=delta,regression_flag=delta>.01 and delta>.1*med['main'])
report=dict(summary=summary,rows=rows,passed=not any(s['regression_flag'] for s in summary.values()))
(b/'cost-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:{n:v for n,v in s.items() if n!='samples'} for k,s in summary.items()},indent=2))
