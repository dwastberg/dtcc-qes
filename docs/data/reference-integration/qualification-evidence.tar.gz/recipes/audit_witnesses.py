import sys,json,io,subprocess
from pathlib import Path
import numpy as np
sys.path.insert(0,'validation')
from dtcc_qes._statistics import _stress_validity
from benchmark_evidence import write_json
b=Path('build/reference-integration');rows=[]
def spectrum(t):
 a=t[..., (0,1,2,1,3,4,2,4,5)].reshape(-1,3,3);return np.linalg.eigvalsh(a)
for name in ('A','E-after'):
 traces=[]
 for arm in ('main','candidate'):
  with np.load(b/'witnesses-002'/(name+'-'+arm)/'trace.npz') as data:traces.append({k:data[k] for k in data.files})
 old,new=traces
 for k in ('cells','weights','orientations','neighbour_flags','gradient_boundary_codes'):
  if k in old:np.testing.assert_array_equal(old[k],new[k])
 columns=[0,1,2,3,4,5,6,7,8,9,10,12]
 np.testing.assert_array_equal(old['properties'][:,columns],new['properties'][:,columns])
 comparisons=[]
 for arm,trace in zip(('main','candidate'),traces,strict=True):
  inputs=np.c_[trace['properties'],trace['orientations']];stream=io.StringIO();np.savetxt(stream,inputs,fmt='%.17g')
  output=subprocess.run([str((b/'qualified-openmp/stress_replay_probe').resolve())],input=stream.getvalue(),text=True,capture_output=True,check=True)
  post=np.fromstring(output.stdout,sep=' ').astype(np.float32).reshape(-1,3,6)[:,0]
  actual=trace['tensors'][1];error=float(np.max(abs(post-actual)/np.maximum(1,np.max(abs(actual),axis=1))[:,None]))
  assert error<16*np.finfo(np.float32).eps
  clipped=np.clip(post,-trace['properties'][:,13,None],trace['properties'][:,13,None])
  np.testing.assert_array_equal(_stress_validity(clipped)[0],_stress_validity(trace['tensors'][2])[0])
  np.testing.assert_array_equal(np.clip(actual,-trace['properties'][:,13,None],trace['properties'][:,13,None]),trace['tensors'][2])
  comparisons.append(dict(arm=arm,maximum_scaled_anisotropy_error=error,source_validity_exact=True))
 valid_old=_stress_validity(old['tensors'][2])[0];valid_new=_stress_validity(new['tensors'][2])[0]
 witnesses=[]
 for i in np.flatnonzero(valid_old&~valid_new):
  witnesses.append(dict(cell=new['cells'][i],weight=new['weights'][i],
   old_minimum_eigenvalues=[spectrum(old['tensors'][j,i:i+1])[0,0] for j in range(3)],
   new_minimum_eigenvalues=[spectrum(new['tensors'][j,i:i+1])[0,0] for j in range(3)],
   internal_energy_before=old['properties'][i,11],internal_energy_after=new['properties'][i,11],
   uncapped_energy=new['properties'][i,12],old_bound=old['properties'][i,13],new_bound=new['properties'][i,13]))
 assert witnesses and all(w['weight']>0 for w in witnesses)
 rows.append(dict(case=name,unchanged_mean_and_construction_inputs=True,native_replay=comparisons,witnesses=witnesses))
write_json(b/'witnesses-002/report.json',dict(passed=True,rows=rows,conclusion='Lower reference bound reduces capped internal energy while shear production stays fixed; the unchanged legacy constitutive/capping path can invalidate source covariances. Boolean validity optimization is exactly equivalent.'))
print(json.dumps(json.loads((b/'witnesses-002/report.json').read_text()),indent=2))
