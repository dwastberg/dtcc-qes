from pathlib import Path
import gzip,hashlib,json,shutil,tarfile,sys
r=Path.cwd();b=r/'build/reference-integration';out=r/'docs/data/reference-integration';out.mkdir(exist_ok=True,parents=True)
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
files={}
for directory in ['aij-directed','witnesses-002','surrey-transition','surrey-background','fixed-mean-stress-002','frozen-reference-replay']:
 for p in (b/directory).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files['runs/'+str(p.relative_to(b))]=p
for p in (b/'policy-workers').iterdir():
 if p.is_file():files['runs/policy-workers/'+p.name]=p
for name in ['main-features','candidate-features']:
 files['runs/'+name+'/manifest.json']=b/name/'manifest.json'
for p in b.glob('*.py'):files['recipes/'+p.name]=p
for p in b.glob('*.json'):
 if p.name!='evidence-manifest.json':files['reports/'+p.name]=p
for p in b.glob('*.xml'):files['tests/'+p.name]=p
for p in Path('/private/tmp').glob('qes-reference*.log'):
 if p.is_file():files['logs/'+p.name]=p
for name in ['qualified-openmp','qualified-serial','sanitizers','openmp']:
 files['builds/'+name+'-identity.txt']=b/name/'solver-policy-identity.txt'
for name in ['main-package','pre-certificate-package','installed-release-wheel']:
 for p in (b/name/'dtcc_qes').glob('_qes*.so'):files['binaries/'+name+'/'+p.name]=p
wheel=next((b/'release-dist').glob('*.whl'));files['artifacts/'+wheel.name]=wheel
manifest=dict(schema='reference-integration-evidence-v1',files={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in sorted(files.items())})
manifest_path=b/'evidence-manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'qualification-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 tar.add(manifest_path,arcname='manifest.json',recursive=False)
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
# Hash-only records for the larger repeated team captures and source distribution.
large={str(p.relative_to(b)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(b.glob('*.npz'))}
sdist=next((b/'staged-dist').glob('*.tar.gz'));large[str(sdist.relative_to(b))]=dict(sha256=sha(sdist),bytes=sdist.stat().st_size)
verification=dict(archive=dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=len(files)+1),
 raw_local_root=str(b),larger_local_artifacts=large,full_capture_bundle=dict(path='/Users/dagwastberg/repos/dtcc/dtcc-qes/validation/output/reference-integration/integration-20261109-001/qualification-captures.tar.gz',sha256='49927a1067b25720cd8f658096b6d4117115d155322faaa16baa12cf0d596e4f',bytes=717249474),policy_identity=sha(b/'openmp/solver-policy-identity.txt'),
 source_epoch='87a48fb plus promoted qualification header; numerical source hashes equal qualified builds',
 original_user_installation_preserved=True)
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
shutil.copyfile(b/'integration-summary.json',out/'summary.json')
shutil.copyfile(b/'openmp/solver-policy-identity.txt',out/'native-build-identity.txt')
print(json.dumps(verification['archive']),flush=True)
