import sys,json,hashlib
from pathlib import Path
from unittest.mock import patch
import numpy as np
from dtcc_qes import wind,_qes
from aij import runner,campaigns
from benchmark_evidence import write_json
name=sys.argv[1];output=Path(sys.argv[2]);output.mkdir()
spec=campaigns.case_ab(name,resolution=2.) if name in ('A','B') else campaigns.case_d(0.,resolution=2.) if name=='D' else campaigns.case_e('WSW',name.split('-')[1],resolution=2.)
spec=campaigns.fixed_work(spec);captured={};original=wind.run
def observed(*args,**kwargs):
 r=original(*args,**kwargs)
 captured['whole_velocity_sha256']=hashlib.sha256(r.velocity.tobytes()).hexdigest()
 captured['reference']=r.metadata['turbulence']['reference'];captured['cap']=r.metadata['turbulence']['cap']
 return r
with patch.object(wind,'run',side_effect=observed): record,arrays=runner.run(spec)
record.update(captured);write_json(output/'record.json',record);np.savez_compressed(output/'arrays.npz',**arrays)
print(name,_qes.solver_policy_revision,record['wall_seconds'],record['peak_rss_bytes'],flush=True)
