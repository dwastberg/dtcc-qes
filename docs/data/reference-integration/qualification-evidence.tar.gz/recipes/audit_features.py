from pathlib import Path
import sys,json,numpy as np
sys.path.insert(0,'tools')
from qualify_reference_integration import compare_impact
b=Path('build/reference-integration');outputs=[]
def flatten(out,name,value):
 if not isinstance(value,dict):out[name]=np.asarray(value);return
 out[name+'/scalars']=np.array(json.dumps({k:v for k,v in value.items() if not isinstance(v,dict)},sort_keys=True))
 for k,v in value.items():
  if isinstance(v,dict):flatten(out,name+'/'+k,v)
for arm in ('main','candidate'):
 folder=b/(arm+'-features');manifest=json.loads((folder/'manifest.json').read_text());out={'_policy_revision':np.array(manifest['policy_revision'])}
 for name,row in manifest['cases'].items():
  record=row.get('metadata',{}).get('solver',{}).get('record')
  if record is not None and record.get('policy'):
   assert record['policy_revision']==manifest['policy_revision'];record['policy_revision']='declared native identity'
  flatten(out,'feature/'+name,row)
  with np.load(folder/(name+'.npz')) as arrays:
   for key in arrays.files:out['feature/'+name+'/'+key]=arrays[key]
 dest=b/(arm+'-features.npz');np.savez(dest,**out);outputs.append(dest)
report=compare_impact(*outputs);(b/'feature-report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['passed'],len(manifest['cases']),report['differences'])
assert report['passed']
