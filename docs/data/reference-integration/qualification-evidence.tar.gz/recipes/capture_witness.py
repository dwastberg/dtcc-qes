import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
import numpy as np
from dtcc_qes import wind,_qes
from aij import runner,campaigns
from frozen_stress_support import stencil
from benchmark_evidence import write_json
name,arm=sys.argv[1:3];b=Path.cwd()/'build/reference-integration';folder=b/'witnesses-002'/(name+'-'+arm);folder.mkdir(parents=True)
spec=campaigns.fixed_work(campaigns.case_ab('A',resolution=2.) if name=='A' else campaigns.case_e('WSW','after',resolution=2.))
a=runner.inputs(spec);settings=a['run'];g=wind._validate_grid(settings['resolution'],settings['bounds'],20.,settings['vertical_clearance'],settings['max_cells'],vertical_grid=settings['vertical_grid'])
geometry,p=wind._prepare_city(a['city'],a['profile'],g,None,'measured',turbulence=True,footprints=settings['footprints'],parameterizations=settings['parameterizations'])
point=np.array([[-4.,0.,34.] if name=='A' else [88.5,-6.,2.]])
nz,ny,nx=p.domain['shape'];axes=[(np.arange(nx)+.5)*p.resolution,(np.arange(ny)+.5)*p.resolution,wind._layer_heights(p)]
s=stencil(dict(axes=axes,solid=np.zeros((nz,ny,nx),bool)),point-np.array(p.origin));take=s['weights'][0]>0
cells=s['indices'][0,take,::-1];weights=s['weights'][0,take]
r=_qes.WindRunner();r.prepare(p.grid,p.model,**p.arrays,dz_layers=p.dz_layers,turbulence=wind._native_turbulence(wind.Turbulence()))
monitor=wind.MonitorSpec(region=(point[0,0]-4,point[0,0]+4,point[0,1]-4,point[0,1]+4),heights=(),receptors=(wind.Receptor('witness',*point[0],required=False),),frame='world',global_mass=False,history_limit=8)
control=replace(settings['solver'],max_solve_seconds=120.,monitor=monitor)._native(p.origin,geometry.crs)
result=r._solve_trace(wind._native_condition(p.domain['profile']),wind._native_solver(settings['solver']),control=control,tensor_cells=cells.tolist(),building_frames=False)
prior=json.loads((b/'aij-directed'/(name+'-'+arm)/'record.json').read_text())
assert hashlib.sha256(result['velocity'].tobytes()).hexdigest()==prior['whole_velocity_sha256']
trace=result['trace'];assert trace['tensor_found'].all()
for c,t in zip(cells,trace['tensors'][2],strict=True):np.testing.assert_array_equal(t,result['turbulence']['stress'][c[2],c[1],c[0]])
np.savez_compressed(folder/'trace.npz',**{k:v for k,v in trace.items() if isinstance(v,np.ndarray)},cells=cells,weights=weights)
write_json(folder/'metadata.json',dict(reference=prior['reference'],cap=prior['cap'],whole_mean_exact=True,policy_revision=_qes.solver_policy_revision))
