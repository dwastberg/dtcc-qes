import os,sys,subprocess,json
from pathlib import Path
b=Path.cwd()/'build/reference-integration';output=b/'aij-directed';output.mkdir();ledger=[]
for n,name in enumerate(('A','B','D','E-before','E-after')):
 for label in (('main','candidate') if n%2==0 else ('candidate','main')):
  package=b/('main-package' if label=='main' else 'qualified-openmp-package')
  folder=output/(name+'-'+label)
  env=os.environ|dict(PYTHONPATH=str(package)+':'+str(Path.cwd()/'validation'),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',DTCC_QES_AIJ_DATA='/Users/dagwastberg/repos/dtcc/dtcc-qes/validation')
  with (output/(name+'-'+label+'.log')).open('w') as stream:
   result=subprocess.run([sys.executable,str(b/'aij_directed_worker.py'),name,str(folder)],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
  ledger.append(dict(case=name,arm=label,returncode=result.returncode));(output/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
  result.check_returncode();print(name,label,'complete',flush=True)
